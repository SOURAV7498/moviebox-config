.class public final Lcom/rmtad/x/AdConfig;
.super Ljava/lang/Object;
.source "AdConfig.java"


# static fields
.field public static final DEFAULT_DELAY:I = 0xa

.field public static final MAX_DELAY:I = 0xe10


# instance fields
.field public final buttonText:Ljava/lang/String;

.field public final delay:I

.field public final force:Z

.field public final icon:Ljava/lang/String;

.field public final image:Ljava/lang/String;

.field public final laterText:Ljava/lang/String;

.field public final message:Ljava/lang/String;

.field public final redirectUrl:Ljava/lang/String;

.field public final show:Z

.field public final showClose:Z

.field public final showLater:Z

.field public final title:Ljava/lang/String;

.field public final type:Ljava/lang/String;


# direct methods
.method private constructor <init>(Lorg/json/JSONObject;)V
    .registers 6

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 34
    const-string v0, "show"

    const/4 v1, 0x0

    invoke-static {p1, v0, v1}, Lcom/rmtad/x/AdConfig;->optBool(Lorg/json/JSONObject;Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/rmtad/x/AdConfig;->show:Z

    .line 35
    const-string v0, "force"

    invoke-static {p1, v0, v1}, Lcom/rmtad/x/AdConfig;->optBool(Lorg/json/JSONObject;Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/rmtad/x/AdConfig;->force:Z

    .line 36
    const-string v0, "show_later"

    invoke-static {p1, v0, v1}, Lcom/rmtad/x/AdConfig;->optBool(Lorg/json/JSONObject;Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/rmtad/x/AdConfig;->showLater:Z

    .line 37
    const-string v0, "show_close"

    invoke-static {p1, v0, v1}, Lcom/rmtad/x/AdConfig;->optBool(Lorg/json/JSONObject;Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/rmtad/x/AdConfig;->showClose:Z

    .line 38
    invoke-static {p1}, Lcom/rmtad/x/AdConfig;->optDelay(Lorg/json/JSONObject;)I

    move-result v0

    iput v0, p0, Lcom/rmtad/x/AdConfig;->delay:I

    .line 40
    const-string v0, "type"

    const/16 v1, 0x10

    invoke-static {p1, v0, v1}, Lcom/rmtad/x/AdConfig;->optStr(Lorg/json/JSONObject;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    .line 41
    const-string v1, "poster"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v2, "message"

    if-eqz v0, :cond_43

    goto :goto_44

    :cond_43
    move-object v1, v2

    :goto_44
    iput-object v1, p0, Lcom/rmtad/x/AdConfig;->type:Ljava/lang/String;

    .line 43
    const-string v0, "image"

    const/16 v1, 0x800

    invoke-static {p1, v0, v1}, Lcom/rmtad/x/AdConfig;->optStr(Lorg/json/JSONObject;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/rmtad/x/AdConfig;->image:Ljava/lang/String;

    .line 44
    const-string v0, "icon"

    invoke-static {p1, v0, v1}, Lcom/rmtad/x/AdConfig;->optStr(Lorg/json/JSONObject;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/rmtad/x/AdConfig;->icon:Ljava/lang/String;

    .line 45
    const-string v0, "title"

    const/16 v3, 0xc8

    invoke-static {p1, v0, v3}, Lcom/rmtad/x/AdConfig;->optStr(Lorg/json/JSONObject;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/rmtad/x/AdConfig;->title:Ljava/lang/String;

    const/16 v0, 0x7d0

    .line 46
    invoke-static {p1, v2, v0}, Lcom/rmtad/x/AdConfig;->optStr(Lorg/json/JSONObject;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/rmtad/x/AdConfig;->message:Ljava/lang/String;

    .line 48
    const-string v0, "button_text"

    const/16 v2, 0x28

    invoke-static {p1, v0, v2}, Lcom/rmtad/x/AdConfig;->optStr(Lorg/json/JSONObject;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    .line 49
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    if-nez v3, :cond_7a

    const-string v0, "OPEN"

    :cond_7a
    iput-object v0, p0, Lcom/rmtad/x/AdConfig;->buttonText:Ljava/lang/String;

    .line 50
    const-string v0, "later_text"

    invoke-static {p1, v0, v2}, Lcom/rmtad/x/AdConfig;->optStr(Lorg/json/JSONObject;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    .line 51
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    if-nez v2, :cond_8a

    const-string v0, "Later"

    :cond_8a
    iput-object v0, p0, Lcom/rmtad/x/AdConfig;->laterText:Ljava/lang/String;

    .line 53
    const-string v0, "redirect_url"

    invoke-static {p1, v0, v1}, Lcom/rmtad/x/AdConfig;->optStr(Lorg/json/JSONObject;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/rmtad/x/AdConfig;->redirectUrl:Ljava/lang/String;

    return-void
.end method

.method public static isValidUrl(Ljava/lang/String;)Z
    .registers 4

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return v0

    .line 90
    :cond_4
    :try_start_4
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    .line 91
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    if-eqz v1, :cond_3f

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0x800

    if-le v1, v2, :cond_17

    goto :goto_3f

    .line 92
    :cond_17
    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    .line 93
    invoke-virtual {p0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v1

    .line 94
    invoke-virtual {p0}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object p0

    if-eqz v1, :cond_3f

    .line 95
    const-string v2, "http"

    .line 96
    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_35

    const-string v2, "https"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3f

    :cond_35
    if-eqz p0, :cond_3f

    .line 97
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0
    :try_end_3b
    .catchall {:try_start_4 .. :try_end_3b} :catchall_3f

    if-lez p0, :cond_3f

    const/4 p0, 0x1

    return p0

    :catchall_3f
    :cond_3f
    :goto_3f
    return v0
.end method

.method private static optBool(Lorg/json/JSONObject;Ljava/lang/String;Z)Z
    .registers 5

    .line 107
    :try_start_0
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_6f

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_6f

    .line 108
    :cond_d
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    .line 109
    instance-of p1, p0, Ljava/lang/Boolean;

    if-eqz p1, :cond_1c

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0

    .line 110
    :cond_1c
    instance-of p1, p0, Ljava/lang/Number;

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_2c

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    if-eqz p0, :cond_2b

    return v0

    :cond_2b
    return v1

    .line 111
    :cond_2c
    instance-of p1, p0, Ljava/lang/String;

    if-eqz p1, :cond_6f

    .line 112
    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    sget-object p1, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p0, p1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    .line 113
    const-string p1, "true"

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6e

    const-string p1, "1"

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6e

    const-string p1, "yes"

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_55

    goto :goto_6e

    .line 114
    :cond_55
    const-string p1, "false"

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6d

    const-string p1, "0"

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6d

    const-string p1, "no"

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0
    :try_end_6b
    .catchall {:try_start_0 .. :try_end_6b} :catchall_6f

    if-eqz p0, :cond_6f

    :cond_6d
    return v1

    :cond_6e
    :goto_6e
    return v0

    :catchall_6f
    :cond_6f
    :goto_6f
    return p2
.end method

.method private static optDelay(Lorg/json/JSONObject;)I
    .registers 7

    .line 123
    const-string v0, "delay"

    const/16 v1, 0xa

    :try_start_4
    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4a

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_11

    goto :goto_4a

    .line 124
    :cond_11
    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    .line 126
    instance-of v0, p0, Ljava/lang/Number;

    if-eqz v0, :cond_20

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v2

    goto :goto_31

    .line 127
    :cond_20
    instance-of v0, p0, Ljava/lang/String;

    if-eqz v0, :cond_2f

    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v2

    goto :goto_31

    :cond_2f
    const-wide/high16 v2, -0x4010000000000000L  # -1.0

    :goto_31
    const-wide/16 v4, 0x0

    cmpl-double p0, v2, v4

    if-gtz p0, :cond_38

    return v1

    :cond_38
    const-wide v4, 0x40ac200000000000L  # 3600.0

    cmpl-double p0, v2, v4

    if-lez p0, :cond_44

    const/16 p0, 0xe10

    return p0

    .line 130
    :cond_44
    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide v0
    :try_end_48
    .catchall {:try_start_4 .. :try_end_48} :catchall_4a

    long-to-int p0, v0

    return p0

    :catchall_4a
    :cond_4a
    :goto_4a
    return v1
.end method

.method private static optStr(Lorg/json/JSONObject;Ljava/lang/String;I)Ljava/lang/String;
    .registers 5

    .line 138
    const-string v0, ""

    :try_start_2
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_34

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_f

    goto :goto_34

    .line 139
    :cond_f
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    .line 140
    instance-of p1, p0, Ljava/lang/String;

    if-nez p1, :cond_20

    instance-of p1, p0, Ljava/lang/Number;

    if-nez p1, :cond_20

    instance-of p1, p0, Ljava/lang/Boolean;

    if-nez p1, :cond_20

    return-object v0

    .line 141
    :cond_20
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    .line 142
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p1

    if-le p1, p2, :cond_33

    const/4 p1, 0x0

    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0
    :try_end_33
    .catchall {:try_start_2 .. :try_end_33} :catchall_34

    :cond_33
    return-object p0

    :catchall_34
    :cond_34
    :goto_34
    return-object v0
.end method

.method public static parse(Ljava/lang/String;)Lcom/rmtad/x/AdConfig;
    .registers 5

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 60
    :cond_4
    :try_start_4
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    .line 61
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x0

    if-lez v1, :cond_21

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const v3, 0xfeff

    if-ne v1, v3, :cond_21

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    .line 62
    :cond_21
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    if-eqz v1, :cond_3b

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x7b

    if-eq v1, v2, :cond_30

    goto :goto_3b

    .line 63
    :cond_30
    new-instance v1, Lcom/rmtad/x/AdConfig;

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-direct {v1, v2}, Lcom/rmtad/x/AdConfig;-><init>(Lorg/json/JSONObject;)V
    :try_end_3a
    .catchall {:try_start_4 .. :try_end_3a} :catchall_3b

    return-object v1

    :catchall_3b
    :cond_3b
    :goto_3b
    return-object v0
.end method


# virtual methods
.method public hasText()Z
    .registers 2

    .line 74
    iget-object v0, p0, Lcom/rmtad/x/AdConfig;->title:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-gtz v0, :cond_13

    iget-object v0, p0, Lcom/rmtad/x/AdConfig;->message:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_11

    goto :goto_13

    :cond_11
    const/4 v0, 0x0

    return v0

    :cond_13
    :goto_13
    const/4 v0, 0x1

    return v0
.end method

.method public hasValidRedirect()Z
    .registers 2

    .line 78
    iget-object v0, p0, Lcom/rmtad/x/AdConfig;->redirectUrl:Ljava/lang/String;

    invoke-static {v0}, Lcom/rmtad/x/AdConfig;->isValidUrl(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public isDisplayable()Z
    .registers 2

    .line 83
    invoke-virtual {p0}, Lcom/rmtad/x/AdConfig;->isPoster()Z

    move-result v0

    if-nez v0, :cond_f

    invoke-virtual {p0}, Lcom/rmtad/x/AdConfig;->hasText()Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_f

    :cond_d
    const/4 v0, 0x0

    return v0

    :cond_f
    :goto_f
    const/4 v0, 0x1

    return v0
.end method

.method public isPoster()Z
    .registers 3

    .line 70
    const-string v0, "poster"

    iget-object v1, p0, Lcom/rmtad/x/AdConfig;->type:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_14

    iget-object v0, p0, Lcom/rmtad/x/AdConfig;->image:Ljava/lang/String;

    invoke-static {v0}, Lcom/rmtad/x/AdConfig;->isValidUrl(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_14

    const/4 v0, 0x1

    return v0

    :cond_14
    const/4 v0, 0x0

    return v0
.end method
