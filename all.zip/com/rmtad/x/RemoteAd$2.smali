.class Lcom/rmtad/x/RemoteAd$2;
.super Ljava/lang/Object;
.source "RemoteAd.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/rmtad/x/RemoteAd;->init(Landroid/app/Activity;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$app:Landroid/content/Context;

.field final synthetic val$configUrl:Ljava/lang/String;

.field final synthetic val$start:J


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;J)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 91
    iput-object p1, p0, Lcom/rmtad/x/RemoteAd$2;->val$app:Landroid/content/Context;

    iput-object p2, p0, Lcom/rmtad/x/RemoteAd$2;->val$configUrl:Ljava/lang/String;

    iput-wide p3, p0, Lcom/rmtad/x/RemoteAd$2;->val$start:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .line 96
    :try_start_0
    iget-object v0, p0, Lcom/rmtad/x/RemoteAd$2;->val$app:Landroid/content/Context;

    iget-object v1, p0, Lcom/rmtad/x/RemoteAd$2;->val$configUrl:Ljava/lang/String;

    iget-wide v2, p0, Lcom/rmtad/x/RemoteAd$2;->val$start:J

    invoke-static {v0, v1, v2, v3}, Lcom/rmtad/x/RemoteAd;->access$000(Landroid/content/Context;Ljava/lang/String;J)Z

    move-result v0
    :try_end_a
    .catchall {:try_start_0 .. :try_end_a} :catchall_e

    .line 99
    invoke-static {v0}, Lcom/rmtad/x/AdSession;->endFetch(Z)V

    return-void

    :catchall_e
    const/4 v0, 0x0

    invoke-static {v0}, Lcom/rmtad/x/AdSession;->endFetch(Z)V

    return-void
.end method
