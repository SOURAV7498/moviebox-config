.class Lcom/rmtad/x/RemoteAd$3;
.super Ljava/lang/Object;
.source "RemoteAd.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/rmtad/x/RemoteAd;->load(Landroid/content/Context;Ljava/lang/String;J)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$due:J

.field final synthetic val$fc:Lcom/rmtad/x/AdConfig;

.field final synthetic val$fi:Landroid/graphics/Bitmap;

.field final synthetic val$fic:Landroid/graphics/Bitmap;


# direct methods
.method constructor <init>(Lcom/rmtad/x/AdConfig;Landroid/graphics/Bitmap;Landroid/graphics/Bitmap;J)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 140
    iput-object p1, p0, Lcom/rmtad/x/RemoteAd$3;->val$fc:Lcom/rmtad/x/AdConfig;

    iput-object p2, p0, Lcom/rmtad/x/RemoteAd$3;->val$fi:Landroid/graphics/Bitmap;

    iput-object p3, p0, Lcom/rmtad/x/RemoteAd$3;->val$fic:Landroid/graphics/Bitmap;

    iput-wide p4, p0, Lcom/rmtad/x/RemoteAd$3;->val$due:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 143
    iget-object v0, p0, Lcom/rmtad/x/RemoteAd$3;->val$fc:Lcom/rmtad/x/AdConfig;

    invoke-static {v0}, Lcom/rmtad/x/RemoteAd;->access$102(Lcom/rmtad/x/AdConfig;)Lcom/rmtad/x/AdConfig;

    .line 144
    iget-object v0, p0, Lcom/rmtad/x/RemoteAd$3;->val$fi:Landroid/graphics/Bitmap;

    invoke-static {v0}, Lcom/rmtad/x/RemoteAd;->access$202(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    .line 145
    iget-object v0, p0, Lcom/rmtad/x/RemoteAd$3;->val$fic:Landroid/graphics/Bitmap;

    invoke-static {v0}, Lcom/rmtad/x/RemoteAd;->access$302(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    .line 146
    iget-wide v0, p0, Lcom/rmtad/x/RemoteAd$3;->val$due:J

    invoke-static {v0, v1}, Lcom/rmtad/x/RemoteAd;->access$402(J)J

    .line 147
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->access$500()V

    return-void
.end method
