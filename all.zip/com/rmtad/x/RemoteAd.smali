.class public final Lcom/rmtad/x/RemoteAd;
.super Ljava/lang/Object;
.source "RemoteAd.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/rmtad/x/RemoteAd$Life;
    }
.end annotation


# static fields
.field private static final CACHE_TTL_MS:J = 0x5265c00L

.field private static final MAIN:Landroid/os/Handler;

.field private static final MAX_ATTACH_RETRIES:I = 0x14

.field private static final MAX_ICON_DIM:I = 0x100

.field private static final MAX_IMAGE_BYTES:I = 0x800000

.field private static final MAX_POSTER_DIM:I = 0x500

.field private static final MAX_TEXT_BYTES:I = 0x10000

.field private static final PREFS:Ljava/lang/String; = "rmtad_cache_v1"

.field private static final TIMEOUT_MS:I = 0x2710

.field private static dueAt:J

.field private static hostClass:Ljava/lang/String;

.field private static hostRef:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field private static lifecycleRegistered:Z

.field private static pending:Ljava/lang/Runnable;

.field private static readyCfg:Lcom/rmtad/x/AdConfig;

.field private static readyIcon:Landroid/graphics/Bitmap;

.field private static readyImage:Landroid/graphics/Bitmap;

.field private static ui:Lcom/rmtad/x/AdUI;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 44
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lcom/rmtad/x/RemoteAd;->MAIN:Landroid/os/Handler;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 57
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Landroid/content/Context;Ljava/lang/String;J)Z
    .registers 4

    .line 33
    invoke-static {p0, p1, p2, p3}, Lcom/rmtad/x/RemoteAd;->load(Landroid/content/Context;Ljava/lang/String;J)Z

    move-result p0

    return p0
.end method

.method static synthetic access$100()Lcom/rmtad/x/AdConfig;
    .registers 1

    .line 33
    sget-object v0, Lcom/rmtad/x/RemoteAd;->readyCfg:Lcom/rmtad/x/AdConfig;

    return-object v0
.end method

.method static synthetic access$1002(Ljava/lang/ref/WeakReference;)Ljava/lang/ref/WeakReference;
    .registers 1

    .line 33
    sput-object p0, Lcom/rmtad/x/RemoteAd;->hostRef:Ljava/lang/ref/WeakReference;

    return-object p0
.end method

.method static synthetic access$102(Lcom/rmtad/x/AdConfig;)Lcom/rmtad/x/AdConfig;
    .registers 1

    .line 33
    sput-object p0, Lcom/rmtad/x/RemoteAd;->readyCfg:Lcom/rmtad/x/AdConfig;

    return-object p0
.end method

.method static synthetic access$1100()Landroid/app/Activity;
    .registers 1

    .line 33
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->host()Landroid/app/Activity;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$1200()V
    .registers 0

    .line 33
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->cancelPending()V

    return-void
.end method

.method static synthetic access$1300()Lcom/rmtad/x/AdUI;
    .registers 1

    .line 33
    sget-object v0, Lcom/rmtad/x/RemoteAd;->ui:Lcom/rmtad/x/AdUI;

    return-object v0
.end method

.method static synthetic access$1302(Lcom/rmtad/x/AdUI;)Lcom/rmtad/x/AdUI;
    .registers 1

    .line 33
    sput-object p0, Lcom/rmtad/x/RemoteAd;->ui:Lcom/rmtad/x/AdUI;

    return-object p0
.end method

.method static synthetic access$202(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    .registers 1

    .line 33
    sput-object p0, Lcom/rmtad/x/RemoteAd;->readyImage:Landroid/graphics/Bitmap;

    return-object p0
.end method

.method static synthetic access$302(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    .registers 1

    .line 33
    sput-object p0, Lcom/rmtad/x/RemoteAd;->readyIcon:Landroid/graphics/Bitmap;

    return-object p0
.end method

.method static synthetic access$402(J)J
    .registers 2

    .line 33
    sput-wide p0, Lcom/rmtad/x/RemoteAd;->dueAt:J

    return-wide p0
.end method

.method static synthetic access$500()V
    .registers 0

    .line 33
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->schedule()V

    return-void
.end method

.method static synthetic access$602(Ljava/lang/Runnable;)Ljava/lang/Runnable;
    .registers 1

    .line 33
    sput-object p0, Lcom/rmtad/x/RemoteAd;->pending:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic access$700(I)V
    .registers 1

    .line 33
    invoke-static {p0}, Lcom/rmtad/x/RemoteAd;->showNow(I)V

    return-void
.end method

.method static synthetic access$900()Ljava/lang/String;
    .registers 1

    .line 33
    sget-object v0, Lcom/rmtad/x/RemoteAd;->hostClass:Ljava/lang/String;

    return-object v0
.end method

.method private static cancelPending()V
    .registers 2

    .line 314
    sget-object v0, Lcom/rmtad/x/RemoteAd;->pending:Ljava/lang/Runnable;

    if-eqz v0, :cond_c

    .line 315
    sget-object v1, Lcom/rmtad/x/RemoteAd;->MAIN:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v0, 0x0

    .line 316
    sput-object v0, Lcom/rmtad/x/RemoteAd;->pending:Ljava/lang/Runnable;

    :cond_c
    return-void
.end method

.method private static clearReady()V
    .registers 1

    const/4 v0, 0x0

    .line 330
    sput-object v0, Lcom/rmtad/x/RemoteAd;->readyCfg:Lcom/rmtad/x/AdConfig;

    .line 331
    sput-object v0, Lcom/rmtad/x/RemoteAd;->readyImage:Landroid/graphics/Bitmap;

    .line 332
    sput-object v0, Lcom/rmtad/x/RemoteAd;->readyIcon:Landroid/graphics/Bitmap;

    .line 333
    sput-object v0, Lcom/rmtad/x/RemoteAd;->ui:Lcom/rmtad/x/AdUI;

    return-void
.end method

.method private static fetchBitmap(Ljava/lang/String;I)Landroid/graphics/Bitmap;
    .registers 8

    const/4 v0, 0x0

    .line 182
    :try_start_1
    invoke-static {p0}, Lcom/rmtad/x/AdConfig;->isValidUrl(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_8

    return-object v0

    .line 183
    :cond_8
    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p0

    check-cast p0, Ljava/net/HttpURLConnection;
    :try_end_13
    .catchall {:try_start_1 .. :try_end_13} :catchall_81

    const/16 v1, 0x2710

    .line 184
    :try_start_15
    invoke-virtual {p0, v1}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 185
    invoke-virtual {p0, v1}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 186
    const-string v1, "User-Agent"

    const-string v2, "RemoteAd/1.0"

    invoke-virtual {p0, v1, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 187
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v1
    :try_end_26
    .catchall {:try_start_15 .. :try_end_26} :catchall_7f

    const/16 v2, 0xc8

    if-eq v1, v2, :cond_30

    if-eqz p0, :cond_2f

    .line 205
    :try_start_2c
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_2f
    .catchall {:try_start_2c .. :try_end_2f} :catchall_2f

    :catchall_2f
    :cond_2f
    return-object v0

    .line 188
    :cond_30
    :try_start_30
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    const/high16 v2, 0x800000

    invoke-static {v1, v2}, Lcom/rmtad/x/RemoteAd;->readAll(Ljava/io/InputStream;I)[B

    move-result-object v1

    if-eqz v1, :cond_79

    .line 189
    array-length v2, v1

    if-nez v2, :cond_40

    goto :goto_79

    .line 191
    :cond_40
    new-instance v2, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v2}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v3, 0x1

    .line 192
    iput-boolean v3, v2, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 193
    array-length v4, v1

    const/4 v5, 0x0

    invoke-static {v1, v5, v4, v2}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 194
    iget v4, v2, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    if-lez v4, :cond_73

    iget v4, v2, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    if-gtz v4, :cond_56

    goto :goto_73

    .line 196
    :cond_56
    :goto_56
    iget v4, v2, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    div-int/2addr v4, v3

    if-gt v4, p1, :cond_70

    iget v4, v2, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    div-int/2addr v4, v3

    if-le v4, p1, :cond_61

    goto :goto_70

    .line 197
    :cond_61
    iput-boolean v5, v2, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 198
    iput v3, v2, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 199
    array-length p1, v1

    invoke-static {v1, v5, p1, v2}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p1
    :try_end_6a
    .catchall {:try_start_30 .. :try_end_6a} :catchall_7f

    if-eqz p0, :cond_6f

    .line 205
    :try_start_6c
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_6f
    .catchall {:try_start_6c .. :try_end_6f} :catchall_6f

    :catchall_6f
    :cond_6f
    return-object p1

    :cond_70
    :goto_70
    mul-int/lit8 v3, v3, 0x2

    goto :goto_56

    :cond_73
    :goto_73
    if-eqz p0, :cond_78

    :try_start_75
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_78
    .catchall {:try_start_75 .. :try_end_78} :catchall_78

    :catchall_78
    :cond_78
    return-object v0

    :cond_79
    :goto_79
    if-eqz p0, :cond_7e

    :try_start_7b
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_7e
    .catchall {:try_start_7b .. :try_end_7e} :catchall_7e

    :catchall_7e
    :cond_7e
    return-object v0

    :catchall_7f
    nop

    goto :goto_83

    :catchall_81
    nop

    move-object p0, v0

    :goto_83
    if-eqz p0, :cond_88

    :try_start_85
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_88
    .catchall {:try_start_85 .. :try_end_88} :catchall_88

    :catchall_88
    :cond_88
    return-object v0
.end method

.method private static host()Landroid/app/Activity;
    .registers 1

    .line 321
    sget-object v0, Lcom/rmtad/x/RemoteAd;->hostRef:Ljava/lang/ref/WeakReference;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    return-object v0

    :cond_6
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/Activity;

    return-object v0
.end method

.method private static httpGetText(Ljava/lang/String;)Ljava/lang/String;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v0, 0x0

    .line 156
    :try_start_1
    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p0

    check-cast p0, Ljava/net/HttpURLConnection;
    :try_end_c
    .catchall {:try_start_1 .. :try_end_c} :catchall_6d

    const/16 v1, 0x2710

    .line 157
    :try_start_e
    invoke-virtual {p0, v1}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 158
    invoke-virtual {p0, v1}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 159
    const-string v1, "GET"

    invoke-virtual {p0, v1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/4 v1, 0x0

    .line 160
    invoke-virtual {p0, v1}, Ljava/net/HttpURLConnection;->setUseCaches(Z)V

    .line 161
    const-string v1, "Cache-Control"

    const-string v2, "no-cache"

    invoke-virtual {p0, v1, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 162
    const-string v1, "Accept"

    const-string v2, "application/json, text/plain, */*"

    invoke-virtual {p0, v1, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 163
    const-string v1, "User-Agent"

    const-string v2, "RemoteAd/1.0"

    invoke-virtual {p0, v1, v2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 164
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v1
    :try_end_36
    .catchall {:try_start_e .. :try_end_36} :catchall_6b

    const/16 v2, 0xc8

    if-eq v1, v2, :cond_40

    if-eqz p0, :cond_3f

    .line 172
    :try_start_3c
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_3f
    .catchall {:try_start_3c .. :try_end_3f} :catchall_3f

    :catchall_3f
    :cond_3f
    return-object v0

    .line 165
    :cond_40
    :try_start_40
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    const/high16 v2, 0x10000

    invoke-static {v1, v2}, Lcom/rmtad/x/RemoteAd;->readAll(Ljava/io/InputStream;I)[B

    move-result-object v1
    :try_end_4a
    .catchall {:try_start_40 .. :try_end_4a} :catchall_6b

    if-nez v1, :cond_52

    if-eqz p0, :cond_51

    .line 172
    :try_start_4e
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_51
    .catchall {:try_start_4e .. :try_end_51} :catchall_51

    :catchall_51
    :cond_51
    return-object v0

    .line 167
    :cond_52
    :try_start_52
    new-instance v2, Ljava/lang/String;

    const-string v3, "UTF-8"

    invoke-direct {v2, v1, v3}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 168
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2
    :try_end_61
    .catchall {:try_start_52 .. :try_end_61} :catchall_6b

    if-nez v2, :cond_64

    goto :goto_65

    :cond_64
    move-object v0, v1

    :goto_65
    if-eqz p0, :cond_6a

    .line 172
    :try_start_67
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_6a
    .catchall {:try_start_67 .. :try_end_6a} :catchall_6a

    :catchall_6a
    :cond_6a
    return-object v0

    :catchall_6b
    move-exception v0

    goto :goto_71

    :catchall_6d
    move-exception p0

    move-object v4, v0

    move-object v0, p0

    move-object p0, v4

    :goto_71
    if-eqz p0, :cond_76

    :try_start_73
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_76
    .catchall {:try_start_73 .. :try_end_76} :catchall_76

    .line 176
    :catchall_76
    :cond_76
    throw v0
.end method

.method public static init(Landroid/app/Activity;Ljava/lang/String;)V
    .registers 6

    if-eqz p0, :cond_73

    .line 65
    :try_start_2
    invoke-static {p1}, Lcom/rmtad/x/AdConfig;->isValidUrl(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_9

    goto :goto_73

    .line 66
    :cond_9
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    if-eq v0, v1, :cond_1e

    .line 67
    sget-object v0, Lcom/rmtad/x/RemoteAd;->MAIN:Landroid/os/Handler;

    new-instance v1, Lcom/rmtad/x/RemoteAd$1;

    invoke-direct {v1, p0, p1}, Lcom/rmtad/x/RemoteAd$1;-><init>(Landroid/app/Activity;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 75
    :cond_1e
    invoke-static {}, Lcom/rmtad/x/AdSession;->isShown()Z

    move-result v0

    if-eqz v0, :cond_25

    goto :goto_73

    .line 77
    :cond_25
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/rmtad/x/RemoteAd;->hostClass:Ljava/lang/String;

    .line 78
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Lcom/rmtad/x/RemoteAd;->hostRef:Ljava/lang/ref/WeakReference;

    .line 79
    invoke-static {p0}, Lcom/rmtad/x/RemoteAd;->registerLifecycle(Landroid/app/Activity;)V

    .line 81
    sget-object v0, Lcom/rmtad/x/RemoteAd;->readyCfg:Lcom/rmtad/x/AdConfig;

    if-eqz v0, :cond_51

    .line 83
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide p0

    sget-object v0, Lcom/rmtad/x/RemoteAd;->readyCfg:Lcom/rmtad/x/AdConfig;

    iget v0, v0, Lcom/rmtad/x/AdConfig;->delay:I

    int-to-long v0, v0

    const-wide/16 v2, 0x3e8

    mul-long v0, v0, v2

    add-long/2addr p0, v0

    sput-wide p0, Lcom/rmtad/x/RemoteAd;->dueAt:J

    .line 84
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->schedule()V

    return-void

    .line 87
    :cond_51
    invoke-static {}, Lcom/rmtad/x/AdSession;->beginFetch()Z

    move-result v0

    if-nez v0, :cond_58

    goto :goto_73

    .line 89
    :cond_58
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 90
    invoke-virtual {p0}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    .line 91
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lcom/rmtad/x/RemoteAd$2;

    invoke-direct {v3, p0, p1, v0, v1}, Lcom/rmtad/x/RemoteAd$2;-><init>(Landroid/content/Context;Ljava/lang/String;J)V

    const-string p0, "rmtad-fetch"

    invoke-direct {v2, v3, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    const/4 p0, 0x1

    .line 103
    invoke-virtual {v2, p0}, Ljava/lang/Thread;->setDaemon(Z)V

    .line 104
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V
    :try_end_73
    .catchall {:try_start_2 .. :try_end_73} :catchall_73

    :catchall_73
    :cond_73
    :goto_73
    return-void
.end method

.method private static isDead(Landroid/app/Activity;)Z
    .registers 3

    .line 325
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_8

    return v1

    .line 326
    :cond_8
    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result p0

    if-eqz p0, :cond_f

    return v1

    :cond_f
    const/4 p0, 0x0

    return p0
.end method

.method private static load(Landroid/content/Context;Ljava/lang/String;J)Z
    .registers 12

    const/4 v0, 0x0

    .line 115
    :try_start_1
    invoke-static {p1}, Lcom/rmtad/x/RemoteAd;->httpGetText(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_5
    .catchall {:try_start_1 .. :try_end_5} :catchall_6

    goto :goto_8

    :catchall_6
    nop

    move-object p1, v0

    .line 119
    :goto_8
    invoke-static {p1}, Lcom/rmtad/x/AdConfig;->parse(Ljava/lang/String;)Lcom/rmtad/x/AdConfig;

    move-result-object v1

    if-eqz v1, :cond_12

    .line 121
    invoke-static {p0, p1}, Lcom/rmtad/x/RemoteAd;->saveCache(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_16

    .line 123
    :cond_12
    invoke-static {p0}, Lcom/rmtad/x/RemoteAd;->loadCache(Landroid/content/Context;)Lcom/rmtad/x/AdConfig;

    move-result-object v1

    :goto_16
    move-object v3, v1

    if-nez v3, :cond_1b

    const/4 p0, 0x0

    return p0

    .line 126
    :cond_1b
    iget-boolean p0, v3, Lcom/rmtad/x/AdConfig;->show:Z

    const/4 p1, 0x1

    if-eqz p0, :cond_60

    invoke-virtual {v3}, Lcom/rmtad/x/AdConfig;->isDisplayable()Z

    move-result p0

    if-nez p0, :cond_27

    goto :goto_60

    .line 130
    :cond_27
    invoke-virtual {v3}, Lcom/rmtad/x/AdConfig;->isPoster()Z

    move-result p0

    if-eqz p0, :cond_38

    .line 131
    iget-object p0, v3, Lcom/rmtad/x/AdConfig;->image:Ljava/lang/String;

    const/16 v1, 0x500

    invoke-static {p0, v1}, Lcom/rmtad/x/RemoteAd;->fetchBitmap(Ljava/lang/String;I)Landroid/graphics/Bitmap;

    move-result-object p0

    move-object v4, p0

    move-object v5, v0

    goto :goto_4d

    .line 132
    :cond_38
    iget-object p0, v3, Lcom/rmtad/x/AdConfig;->icon:Ljava/lang/String;

    invoke-static {p0}, Lcom/rmtad/x/AdConfig;->isValidUrl(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_4b

    .line 133
    iget-object p0, v3, Lcom/rmtad/x/AdConfig;->icon:Ljava/lang/String;

    const/16 v1, 0x100

    invoke-static {p0, v1}, Lcom/rmtad/x/RemoteAd;->fetchBitmap(Ljava/lang/String;I)Landroid/graphics/Bitmap;

    move-result-object p0

    move-object v5, p0

    move-object v4, v0

    goto :goto_4d

    :cond_4b
    move-object v4, v0

    move-object v5, v4

    .line 139
    :goto_4d
    iget p0, v3, Lcom/rmtad/x/AdConfig;->delay:I

    int-to-long v0, p0

    const-wide/16 v6, 0x3e8

    mul-long v0, v0, v6

    add-long v6, p2, v0

    .line 140
    sget-object p0, Lcom/rmtad/x/RemoteAd;->MAIN:Landroid/os/Handler;

    new-instance v2, Lcom/rmtad/x/RemoteAd$3;

    invoke-direct/range {v2 .. v7}, Lcom/rmtad/x/RemoteAd$3;-><init>(Lcom/rmtad/x/AdConfig;Landroid/graphics/Bitmap;Landroid/graphics/Bitmap;J)V

    invoke-virtual {p0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_60
    :goto_60
    return p1
.end method

.method private static loadCache(Landroid/content/Context;)Lcom/rmtad/x/AdConfig;
    .registers 9

    const/4 v0, 0x0

    .line 245
    :try_start_1
    const-string v1, "rmtad_cache_v1"

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 246
    const-string v1, "ts"

    const-wide/16 v2, 0x0

    invoke-interface {p0, v1, v2, v3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v4

    .line 247
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    sub-long/2addr v6, v4

    cmp-long v1, v4, v2

    if-lez v1, :cond_30

    cmp-long v1, v6, v2

    if-ltz v1, :cond_30

    const-wide/32 v1, 0x5265c00

    cmp-long v3, v6, v1

    if-lez v3, :cond_25

    goto :goto_30

    .line 249
    :cond_25
    const-string v1, "raw"

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/rmtad/x/AdConfig;->parse(Ljava/lang/String;)Lcom/rmtad/x/AdConfig;

    move-result-object p0
    :try_end_2f
    .catchall {:try_start_1 .. :try_end_2f} :catchall_30

    return-object p0

    :catchall_30
    :cond_30
    :goto_30
    return-object v0
.end method

.method static onUiClosed()V
    .registers 0

    .line 338
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->cancelPending()V

    .line 339
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->clearReady()V

    return-void
.end method

.method static openUrl(Landroid/app/Activity;Ljava/lang/String;)Z
    .registers 5

    const/4 v0, 0x0

    .line 347
    :try_start_1
    invoke-static {p1}, Lcom/rmtad/x/AdConfig;->isValidUrl(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_8

    return v0

    .line 348
    :cond_8
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-direct {v1, v2, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 349
    const-string p1, "android.intent.category.BROWSABLE"

    invoke-virtual {v1, p1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 350
    invoke-virtual {p0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_1f
    .catch Landroid/content/ActivityNotFoundException; {:try_start_1 .. :try_end_1f} :catch_22
    .catchall {:try_start_1 .. :try_end_1f} :catchall_21

    const/4 p0, 0x1

    return p0

    :catchall_21
    return v0

    .line 354
    :catch_22
    :try_start_22
    const-string p1, "No app found to open this link"

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V
    :try_end_2b
    .catchall {:try_start_22 .. :try_end_2b} :catchall_2b

    :catchall_2b
    return v0
.end method

.method private static postShow(JI)V
    .registers 4

    .line 270
    new-instance v0, Lcom/rmtad/x/RemoteAd$4;

    invoke-direct {v0, p2}, Lcom/rmtad/x/RemoteAd$4;-><init>(I)V

    sput-object v0, Lcom/rmtad/x/RemoteAd;->pending:Ljava/lang/Runnable;

    .line 277
    sget-object p2, Lcom/rmtad/x/RemoteAd;->MAIN:Landroid/os/Handler;

    invoke-virtual {p2, v0, p0, p1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private static readAll(Ljava/io/InputStream;I)[B
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 215
    :try_start_0
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v1, 0x2000

    .line 216
    new-array v1, v1, [B

    .line 218
    :cond_9
    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    const/4 v3, -0x1

    if-eq v2, v3, :cond_1f

    const/4 v3, 0x0

    .line 219
    invoke-virtual {v0, v1, v3, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 220
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v2
    :try_end_18
    .catchall {:try_start_0 .. :try_end_18} :catchall_27

    if-le v2, p1, :cond_9

    const/4 p1, 0x0

    .line 225
    :try_start_1b
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_1e
    .catchall {:try_start_1b .. :try_end_1e} :catchall_1e

    :catchall_1e
    return-object p1

    .line 222
    :cond_1f
    :try_start_1f
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1
    :try_end_23
    .catchall {:try_start_1f .. :try_end_23} :catchall_27

    .line 225
    :try_start_23
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_26
    .catchall {:try_start_23 .. :try_end_26} :catchall_26

    :catchall_26
    return-object p1

    :catchall_27
    move-exception p1

    :try_start_28
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_2b
    .catchall {:try_start_28 .. :try_end_2b} :catchall_2b

    .line 228
    :catchall_2b
    throw p1
.end method

.method private static registerLifecycle(Landroid/app/Activity;)V
    .registers 3

    .line 366
    sget-boolean v0, Lcom/rmtad/x/RemoteAd;->lifecycleRegistered:Z

    if-eqz v0, :cond_5

    goto :goto_17

    .line 368
    :cond_5
    :try_start_5
    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object p0

    if-eqz p0, :cond_17

    .line 370
    new-instance v0, Lcom/rmtad/x/RemoteAd$Life;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/rmtad/x/RemoteAd$Life;-><init>(Lcom/rmtad/x/RemoteAd$1;)V

    invoke-virtual {p0, v0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 p0, 0x1

    .line 371
    sput-boolean p0, Lcom/rmtad/x/RemoteAd;->lifecycleRegistered:Z
    :try_end_17
    .catchall {:try_start_5 .. :try_end_17} :catchall_17

    :catchall_17
    :cond_17
    :goto_17
    return-void
.end method

.method private static saveCache(Landroid/content/Context;Ljava/lang/String;)V
    .registers 4

    .line 235
    :try_start_0
    const-string v0, "rmtad_cache_v1"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "raw"

    .line 236
    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string p1, "ts"

    .line 237
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    invoke-interface {p0, p1, v0, v1}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    .line 238
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_1e
    .catchall {:try_start_0 .. :try_end_1e} :catchall_1e

    :catchall_1e
    return-void
.end method

.method private static schedule()V
    .registers 4

    .line 259
    :try_start_0
    sget-object v0, Lcom/rmtad/x/RemoteAd;->readyCfg:Lcom/rmtad/x/AdConfig;

    if-eqz v0, :cond_32

    invoke-static {}, Lcom/rmtad/x/AdSession;->isShown()Z

    move-result v0

    if-nez v0, :cond_32

    invoke-static {}, Lcom/rmtad/x/AdSession;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_11

    goto :goto_32

    .line 260
    :cond_11
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->host()Landroid/app/Activity;

    move-result-object v0

    if-eqz v0, :cond_32

    .line 261
    invoke-static {v0}, Lcom/rmtad/x/RemoteAd;->isDead(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_1e

    goto :goto_32

    .line 262
    :cond_1e
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->cancelPending()V

    .line 263
    sget-wide v0, Lcom/rmtad/x/RemoteAd;->dueAt:J

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x0

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    const/4 v2, 0x0

    .line 264
    invoke-static {v0, v1, v2}, Lcom/rmtad/x/RemoteAd;->postShow(JI)V
    :try_end_32
    .catchall {:try_start_0 .. :try_end_32} :catchall_32

    :catchall_32
    :cond_32
    :goto_32
    return-void
.end method

.method private static showNow(I)V
    .registers 5

    .line 282
    :try_start_0
    sget-object v0, Lcom/rmtad/x/RemoteAd;->readyCfg:Lcom/rmtad/x/AdConfig;

    if-eqz v0, :cond_67

    invoke-static {}, Lcom/rmtad/x/AdSession;->isShown()Z

    move-result v0

    if-nez v0, :cond_67

    invoke-static {}, Lcom/rmtad/x/AdSession;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_11

    goto :goto_67

    .line 283
    :cond_11
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->host()Landroid/app/Activity;

    move-result-object v0

    if-eqz v0, :cond_67

    .line 284
    invoke-static {v0}, Lcom/rmtad/x/RemoteAd;->isDead(Landroid/app/Activity;)Z

    move-result v1

    if-eqz v1, :cond_1e

    goto :goto_67

    .line 287
    :cond_1e
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-eqz v1, :cond_5c

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v1

    if-nez v1, :cond_33

    goto :goto_5c

    .line 291
    :cond_33
    invoke-static {}, Lcom/rmtad/x/AdSession;->beginShow()Z

    move-result p0

    if-nez p0, :cond_3a

    goto :goto_67

    .line 293
    :cond_3a
    new-instance p0, Lcom/rmtad/x/AdUI;

    invoke-direct {p0}, Lcom/rmtad/x/AdUI;-><init>()V
    :try_end_3f
    .catchall {:try_start_0 .. :try_end_3f} :catchall_68

    .line 296
    :try_start_3f
    sget-object v1, Lcom/rmtad/x/RemoteAd;->readyCfg:Lcom/rmtad/x/AdConfig;

    sget-object v2, Lcom/rmtad/x/RemoteAd;->readyImage:Landroid/graphics/Bitmap;

    sget-object v3, Lcom/rmtad/x/RemoteAd;->readyIcon:Landroid/graphics/Bitmap;

    invoke-virtual {p0, v0, v1, v2, v3}, Lcom/rmtad/x/AdUI;->show(Landroid/app/Activity;Lcom/rmtad/x/AdConfig;Landroid/graphics/Bitmap;Landroid/graphics/Bitmap;)Z

    move-result v0
    :try_end_49
    .catchall {:try_start_3f .. :try_end_49} :catchall_58

    if-eqz v0, :cond_4e

    .line 302
    :try_start_4b
    sput-object p0, Lcom/rmtad/x/RemoteAd;->ui:Lcom/rmtad/x/AdUI;

    return-void

    .line 304
    :cond_4e
    invoke-static {}, Lcom/rmtad/x/AdSession;->endShow()V

    .line 305
    invoke-static {}, Lcom/rmtad/x/AdSession;->markShown()V

    .line 306
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->clearReady()V

    return-void

    .line 298
    :catchall_58
    invoke-static {}, Lcom/rmtad/x/AdSession;->endShow()V

    goto :goto_67

    :cond_5c
    :goto_5c
    const/16 v0, 0x14

    if-ge p0, v0, :cond_67

    add-int/lit8 p0, p0, 0x1

    const-wide/16 v0, 0x1f4

    .line 288
    invoke-static {v0, v1, p0}, Lcom/rmtad/x/RemoteAd;->postShow(JI)V
    :try_end_67
    .catchall {:try_start_4b .. :try_end_67} :catchall_68

    :cond_67
    :goto_67
    return-void

    .line 309
    :catchall_68
    invoke-static {}, Lcom/rmtad/x/AdSession;->endShow()V

    return-void
.end method
