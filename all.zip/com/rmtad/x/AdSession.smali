.class public final Lcom/rmtad/x/AdSession;
.super Ljava/lang/Object;
.source "AdSession.java"


# static fields
.field private static volatile fetchDone:Z

.field private static final fetching:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final redirecting:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static final showing:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static volatile shown:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 13
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v0, Lcom/rmtad/x/AdSession;->fetching:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 14
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v0, Lcom/rmtad/x/AdSession;->showing:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 15
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v0, Lcom/rmtad/x/AdSession;->redirecting:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static beginFetch()Z
    .registers 3

    .line 34
    sget-boolean v0, Lcom/rmtad/x/AdSession;->fetchDone:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    return v1

    .line 35
    :cond_6
    sget-object v0, Lcom/rmtad/x/AdSession;->fetching:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    return v0
.end method

.method public static beginRedirect()Z
    .registers 3

    .line 54
    sget-object v0, Lcom/rmtad/x/AdSession;->redirecting:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    return v0
.end method

.method public static beginShow()Z
    .registers 3

    .line 45
    sget-boolean v0, Lcom/rmtad/x/AdSession;->shown:Z

    const/4 v1, 0x0

    if-nez v0, :cond_f

    sget-object v0, Lcom/rmtad/x/AdSession;->showing:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-eqz v0, :cond_f

    return v2

    :cond_f
    return v1
.end method

.method public static endFetch(Z)V
    .registers 2

    if-eqz p0, :cond_5

    const/4 p0, 0x1

    .line 39
    sput-boolean p0, Lcom/rmtad/x/AdSession;->fetchDone:Z

    .line 40
    :cond_5
    sget-object p0, Lcom/rmtad/x/AdSession;->fetching:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-void
.end method

.method public static endShow()V
    .registers 2

    .line 49
    sget-object v0, Lcom/rmtad/x/AdSession;->showing:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-void
.end method

.method public static isShowing()Z
    .registers 1

    .line 29
    sget-object v0, Lcom/rmtad/x/AdSession;->showing:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    return v0
.end method

.method public static isShown()Z
    .registers 1

    .line 21
    sget-boolean v0, Lcom/rmtad/x/AdSession;->shown:Z

    return v0
.end method

.method public static markShown()V
    .registers 1

    const/4 v0, 0x1

    .line 25
    sput-boolean v0, Lcom/rmtad/x/AdSession;->shown:Z

    return-void
.end method
