.class Lcom/rmtad/x/AdUI$1;
.super Ljava/lang/Object;
.source "AdUI.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/rmtad/x/AdUI;->show(Landroid/app/Activity;Lcom/rmtad/x/AdConfig;Landroid/graphics/Bitmap;Landroid/graphics/Bitmap;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/rmtad/x/AdUI;


# direct methods
.method constructor <init>(Lcom/rmtad/x/AdUI;)V
    .registers 2

    .line 153
    iput-object p1, p0, Lcom/rmtad/x/AdUI$1;->this$0:Lcom/rmtad/x/AdUI;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 2

    .line 156
    iget-object p1, p0, Lcom/rmtad/x/AdUI$1;->this$0:Lcom/rmtad/x/AdUI;

    invoke-static {p1}, Lcom/rmtad/x/AdUI;->access$000(Lcom/rmtad/x/AdUI;)V

    return-void
.end method
