.class public final Lcom/rmtad/x/AdUI;
.super Ljava/lang/Object;
.source "AdUI.java"


# static fields
.field private static final C_ACCENT:I

.field private static final C_ACCENT_DOWN:I

.field private static final C_CARD:I

.field private static final C_MUTED:I

.field private static final C_SCRIM:I

.field private static final C_TEXT:I

.field private static final C_TITLE:I


# instance fields
.field private activity:Landroid/app/Activity;

.field private cfg:Lcom/rmtad/x/AdConfig;

.field private density:F

.field private dialog:Landroid/app/Dialog;

.field private volatile done:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 36
    const-string v0, "#1C1D24"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    sput v0, Lcom/rmtad/x/AdUI;->C_CARD:I

    .line 37
    const-string v0, "#FFFFFF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    sput v0, Lcom/rmtad/x/AdUI;->C_TITLE:I

    .line 38
    const-string v0, "#B9BDC9"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    sput v0, Lcom/rmtad/x/AdUI;->C_TEXT:I

    .line 39
    const-string v0, "#4F8CFF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    sput v0, Lcom/rmtad/x/AdUI;->C_ACCENT:I

    .line 40
    const-string v0, "#3A6FD6"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    sput v0, Lcom/rmtad/x/AdUI;->C_ACCENT_DOWN:I

    .line 41
    const-string v0, "#8E93A3"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    sput v0, Lcom/rmtad/x/AdUI;->C_MUTED:I

    .line 42
    const-string v0, "#99000000"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    sput v0, Lcom/rmtad/x/AdUI;->C_SCRIM:I

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 v0, 0x3f800000  # 1.0f

    .line 48
    iput v0, p0, Lcom/rmtad/x/AdUI;->density:F

    return-void
.end method

.method static synthetic access$000(Lcom/rmtad/x/AdUI;)V
    .registers 1

    .line 34
    invoke-direct {p0}, Lcom/rmtad/x/AdUI;->finishByUser()V

    return-void
.end method

.method static synthetic access$100(Lcom/rmtad/x/AdUI;)V
    .registers 1

    .line 34
    invoke-direct {p0}, Lcom/rmtad/x/AdUI;->onAction()V

    return-void
.end method

.method private addButtons(Landroid/widget/LinearLayout;IIII)V
    .registers 11

    .line 216
    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lcom/rmtad/x/AdUI;->activity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 217
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 218
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 219
    invoke-virtual {v0, p2, p3, p4, p5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 221
    new-instance p2, Landroid/widget/TextView;

    iget-object p3, p0, Lcom/rmtad/x/AdUI;->activity:Landroid/app/Activity;

    invoke-direct {p2, p3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 222
    iget-object p3, p0, Lcom/rmtad/x/AdUI;->cfg:Lcom/rmtad/x/AdConfig;

    iget-object p3, p3, Lcom/rmtad/x/AdConfig;->buttonText:Ljava/lang/String;

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 p3, -0x1

    .line 223
    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 p4, 0x41800000  # 16.0f

    const/4 p5, 0x2

    .line 224
    invoke-virtual {p2, p5, p4}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 225
    sget-object p4, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {p2, p4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/16 p4, 0x11

    .line 226
    invoke-virtual {p2, p4}, Landroid/widget/TextView;->setGravity(I)V

    .line 227
    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setClickable(Z)V

    .line 228
    sget v2, Lcom/rmtad/x/AdUI;->C_ACCENT:I

    sget v3, Lcom/rmtad/x/AdUI;->C_ACCENT_DOWN:I

    const/16 v4, 0xe

    invoke-direct {p0, v4}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v4

    int-to-float v4, v4

    invoke-static {v2, v3, v4}, Lcom/rmtad/x/AdUI;->pill(IIF)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-static {p2, v2}, Lcom/rmtad/x/AdUI;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 229
    new-instance v2, Lcom/rmtad/x/AdUI$4;

    invoke-direct {v2, p0}, Lcom/rmtad/x/AdUI$4;-><init>(Lcom/rmtad/x/AdUI;)V

    invoke-virtual {p2, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 235
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x32

    .line 236
    invoke-direct {p0, v3}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v3

    invoke-direct {v2, p3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 235
    invoke-virtual {v0, p2, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 239
    iget-object p2, p0, Lcom/rmtad/x/AdUI;->cfg:Lcom/rmtad/x/AdConfig;

    iget-boolean p2, p2, Lcom/rmtad/x/AdConfig;->force:Z

    const/4 v2, -0x2

    if-nez p2, :cond_b1

    iget-object p2, p0, Lcom/rmtad/x/AdUI;->cfg:Lcom/rmtad/x/AdConfig;

    iget-boolean p2, p2, Lcom/rmtad/x/AdConfig;->showLater:Z

    if-eqz p2, :cond_b1

    .line 240
    new-instance p2, Landroid/widget/TextView;

    iget-object v3, p0, Lcom/rmtad/x/AdUI;->activity:Landroid/app/Activity;

    invoke-direct {p2, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 241
    iget-object v3, p0, Lcom/rmtad/x/AdUI;->cfg:Lcom/rmtad/x/AdConfig;

    iget-object v3, v3, Lcom/rmtad/x/AdConfig;->laterText:Ljava/lang/String;

    invoke-virtual {p2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 242
    sget v3, Lcom/rmtad/x/AdUI;->C_MUTED:I

    invoke-virtual {p2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v3, 0x41600000  # 14.0f

    .line 243
    invoke-virtual {p2, p5, v3}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 244
    invoke-virtual {p2, p4}, Landroid/widget/TextView;->setGravity(I)V

    .line 245
    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setClickable(Z)V

    const/16 p4, 0x10

    .line 246
    invoke-direct {p0, p4}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result p5

    const/16 v1, 0xa

    invoke-direct {p0, v1}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v1

    invoke-direct {p0, p4}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result p4

    const/4 v3, 0x6

    invoke-direct {p0, v3}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v3

    invoke-virtual {p2, p5, v1, p4, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 247
    new-instance p4, Lcom/rmtad/x/AdUI$5;

    invoke-direct {p4, p0}, Lcom/rmtad/x/AdUI$5;-><init>(Lcom/rmtad/x/AdUI;)V

    invoke-virtual {p2, p4}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 253
    new-instance p4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p4, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p2, p4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 257
    :cond_b1
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p2, p3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v0, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private closeAndMarkShown()V
    .registers 2

    .line 282
    invoke-static {}, Lcom/rmtad/x/AdSession;->markShown()V

    .line 284
    :try_start_3
    iget-object v0, p0, Lcom/rmtad/x/AdUI;->dialog:Landroid/app/Dialog;

    if-eqz v0, :cond_12

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_12

    iget-object v0, p0, Lcom/rmtad/x/AdUI;->dialog:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    :try_end_12
    .catchall {:try_start_3 .. :try_end_12} :catchall_12

    :catchall_12
    :cond_12
    const/4 v0, 0x0

    .line 287
    iput-object v0, p0, Lcom/rmtad/x/AdUI;->dialog:Landroid/app/Dialog;

    .line 288
    iput-object v0, p0, Lcom/rmtad/x/AdUI;->activity:Landroid/app/Activity;

    .line 289
    invoke-static {}, Lcom/rmtad/x/AdSession;->endShow()V

    .line 290
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->onUiClosed()V

    return-void
.end method

.method private dp(I)I
    .registers 3

    int-to-float p1, p1

    .line 294
    iget v0, p0, Lcom/rmtad/x/AdUI;->density:F

    mul-float p1, p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method

.method private finishByUser()V
    .registers 2

    .line 276
    iget-boolean v0, p0, Lcom/rmtad/x/AdUI;->done:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    .line 277
    iput-boolean v0, p0, Lcom/rmtad/x/AdUI;->done:Z

    .line 278
    invoke-direct {p0}, Lcom/rmtad/x/AdUI;->closeAndMarkShown()V

    return-void
.end method

.method private onAction()V
    .registers 3

    .line 262
    iget-boolean v0, p0, Lcom/rmtad/x/AdUI;->done:Z

    if-eqz v0, :cond_5

    goto :goto_b

    .line 263
    :cond_5
    invoke-static {}, Lcom/rmtad/x/AdSession;->beginRedirect()Z

    move-result v0

    if-nez v0, :cond_c

    :goto_b
    return-void

    :cond_c
    const/4 v0, 0x1

    .line 264
    iput-boolean v0, p0, Lcom/rmtad/x/AdUI;->done:Z

    .line 266
    :try_start_f
    iget-object v0, p0, Lcom/rmtad/x/AdUI;->cfg:Lcom/rmtad/x/AdConfig;

    invoke-virtual {v0}, Lcom/rmtad/x/AdConfig;->hasValidRedirect()Z

    move-result v0

    if-eqz v0, :cond_22

    iget-object v0, p0, Lcom/rmtad/x/AdUI;->activity:Landroid/app/Activity;

    if-eqz v0, :cond_22

    .line 267
    iget-object v1, p0, Lcom/rmtad/x/AdUI;->cfg:Lcom/rmtad/x/AdConfig;

    iget-object v1, v1, Lcom/rmtad/x/AdConfig;->redirectUrl:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/rmtad/x/RemoteAd;->openUrl(Landroid/app/Activity;Ljava/lang/String;)Z
    :try_end_22
    .catchall {:try_start_f .. :try_end_22} :catchall_22

    .line 272
    :catchall_22
    :cond_22
    invoke-direct {p0}, Lcom/rmtad/x/AdUI;->closeAndMarkShown()V

    return-void
.end method

.method private static pill(IIF)Landroid/graphics/drawable/Drawable;
    .registers 4

    .line 303
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 304
    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 305
    invoke-virtual {v0, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 306
    new-instance p0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {p0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 307
    invoke-virtual {p0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 308
    invoke-virtual {p0, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 309
    new-instance p1, Landroid/graphics/drawable/StateListDrawable;

    invoke-direct {p1}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    const p2, 0x10100a7

    .line 310
    filled-new-array {p2}, [I

    move-result-object p2

    invoke-virtual {p1, p2, p0}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    const/4 p0, 0x0

    .line 311
    new-array p0, p0, [I

    invoke-virtual {p1, p0, v0}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    return-object p1
.end method

.method private static roundTop(Landroid/graphics/Bitmap;F)Landroid/graphics/Bitmap;
    .registers 11

    .line 318
    :try_start_0
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    .line 319
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    .line 320
    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v0, v1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 321
    new-instance v3, Landroid/graphics/Canvas;

    invoke-direct {v3, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 322
    new-instance v4, Landroid/graphics/Paint;

    const/4 v5, 0x1

    invoke-direct {v4, v5}, Landroid/graphics/Paint;-><init>(I)V

    .line 323
    new-instance v6, Landroid/graphics/BitmapShader;

    sget-object v7, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    sget-object v8, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct {v6, p0, v7, v8}, Landroid/graphics/BitmapShader;-><init>(Landroid/graphics/Bitmap;Landroid/graphics/Shader$TileMode;Landroid/graphics/Shader$TileMode;)V

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 324
    new-instance v6, Landroid/graphics/Path;

    invoke-direct {v6}, Landroid/graphics/Path;-><init>()V

    .line 325
    new-instance v7, Landroid/graphics/RectF;

    int-to-float v0, v0

    int-to-float v1, v1

    const/4 v8, 0x0

    invoke-direct {v7, v8, v8, v0, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/16 v0, 0x8

    new-array v0, v0, [F

    const/4 v1, 0x0

    aput p1, v0, v1

    aput p1, v0, v5

    const/4 v1, 0x2

    aput p1, v0, v1

    const/4 v1, 0x3

    aput p1, v0, v1

    const/4 p1, 0x4

    aput v8, v0, p1

    const/4 p1, 0x5

    aput v8, v0, p1

    const/4 p1, 0x6

    aput v8, v0, p1

    const/4 p1, 0x7

    aput v8, v0, p1

    sget-object p1, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {v6, v7, v0, p1}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;[FLandroid/graphics/Path$Direction;)V

    .line 328
    invoke-virtual {v3, v6, v4}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V
    :try_end_55
    .catchall {:try_start_0 .. :try_end_55} :catchall_56

    return-object v2

    :catchall_56
    return-object p0
.end method

.method private static setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V
    .registers 2

    .line 298
    invoke-virtual {p0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method


# virtual methods
.method public dismissSilently()V
    .registers 2

    .line 205
    :try_start_0
    iget-object v0, p0, Lcom/rmtad/x/AdUI;->dialog:Landroid/app/Dialog;

    if-eqz v0, :cond_f

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_f

    iget-object v0, p0, Lcom/rmtad/x/AdUI;->dialog:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    :try_end_f
    .catchall {:try_start_0 .. :try_end_f} :catchall_f

    :catchall_f
    :cond_f
    const/4 v0, 0x0

    .line 208
    iput-object v0, p0, Lcom/rmtad/x/AdUI;->dialog:Landroid/app/Dialog;

    .line 209
    iput-object v0, p0, Lcom/rmtad/x/AdUI;->activity:Landroid/app/Activity;

    .line 210
    invoke-static {}, Lcom/rmtad/x/AdSession;->endShow()V

    return-void
.end method

.method public show(Landroid/app/Activity;Lcom/rmtad/x/AdConfig;Landroid/graphics/Bitmap;Landroid/graphics/Bitmap;)Z
    .registers 22

    move-object/from16 v0, p0

    move-object/from16 v6, p1

    move-object/from16 v7, p2

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    .line 55
    iput-object v6, v0, Lcom/rmtad/x/AdUI;->activity:Landroid/app/Activity;

    .line 56
    iput-object v7, v0, Lcom/rmtad/x/AdUI;->cfg:Lcom/rmtad/x/AdConfig;

    .line 58
    invoke-virtual {v7}, Lcom/rmtad/x/AdConfig;->isPoster()Z

    move-result v3

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v3, :cond_1a

    if-eqz v1, :cond_1a

    const/4 v3, 0x1

    goto :goto_1b

    :cond_1a
    const/4 v3, 0x0

    :goto_1b
    if-nez v3, :cond_24

    .line 59
    invoke-virtual {v7}, Lcom/rmtad/x/AdConfig;->hasText()Z

    move-result v4

    if-nez v4, :cond_24

    return v8

    .line 61
    :cond_24
    invoke-virtual {v6}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    .line 62
    iget v5, v4, Landroid/util/DisplayMetrics;->density:F

    iput v5, v0, Lcom/rmtad/x/AdUI;->density:F

    .line 63
    iget v5, v4, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v5, v5

    const v10, 0x3f666666  # 0.9f

    mul-float v5, v5, v10

    float-to-int v5, v5

    const/16 v10, 0x1a4

    invoke-direct {v0, v10}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v10

    invoke-static {v5, v10}, Ljava/lang/Math;->min(II)I

    move-result v10

    .line 65
    iget-boolean v11, v7, Lcom/rmtad/x/AdConfig;->force:Z

    .line 67
    new-instance v12, Landroid/app/Dialog;

    invoke-direct {v12, v6}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    .line 68
    invoke-virtual {v12, v9}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 70
    new-instance v13, Landroid/widget/FrameLayout;

    invoke-direct {v13, v6}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 71
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 72
    sget v14, Lcom/rmtad/x/AdUI;->C_CARD:I

    invoke-virtual {v5, v14}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 v14, 0x14

    .line 73
    invoke-direct {v0, v14}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v15

    int-to-float v15, v15

    invoke-virtual {v5, v15}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 74
    invoke-static {v13, v5}, Lcom/rmtad/x/AdUI;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 76
    new-instance v5, Landroid/widget/ScrollView;

    invoke-direct {v5, v6}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 77
    invoke-virtual {v5, v8}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    .line 78
    invoke-virtual {v5, v8}, Landroid/widget/ScrollView;->setVerticalScrollBarEnabled(Z)V

    .line 79
    new-instance v15, Landroid/widget/LinearLayout;

    invoke-direct {v15, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 80
    invoke-virtual {v15, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 81
    new-instance v8, Landroid/view/ViewGroup$LayoutParams;

    const/4 v14, -0x1

    const/4 v9, -0x2

    invoke-direct {v8, v14, v9}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v15, v8}, Landroid/widget/ScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 83
    new-instance v8, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v8, v14, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v13, v5, v8}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v8, 0x2

    const/16 v5, 0x10

    if-eqz v3, :cond_f0

    .line 87
    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, v6}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x1

    .line 88
    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setAdjustViewBounds(Z)V

    .line 89
    sget-object v3, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 90
    iget v3, v4, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v3, v3

    const v4, 0x3f19999a  # 0.6f

    mul-float v3, v3, v4

    float-to-int v3, v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setMaxHeight(I)V

    const/16 v3, 0x14

    .line 91
    invoke-direct {v0, v3}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v3

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    mul-int v3, v3, v4

    int-to-float v3, v3

    int-to-float v4, v10

    div-float/2addr v3, v4

    invoke-static {v1, v3}, Lcom/rmtad/x/AdUI;->roundTop(Landroid/graphics/Bitmap;F)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 92
    iget-object v1, v7, Lcom/rmtad/x/AdConfig;->title:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_d0

    iget-object v1, v7, Lcom/rmtad/x/AdConfig;->title:Ljava/lang/String;

    invoke-virtual {v2, v1}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 93
    :cond_d0
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v14, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v15, v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 95
    invoke-direct {v0, v5}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v2

    invoke-direct {v0, v5}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v3

    invoke-direct {v0, v5}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v4

    invoke-direct {v0, v5}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v5

    move-object v1, v15

    const/16 v15, 0xa

    invoke-direct/range {v0 .. v5}, Lcom/rmtad/x/AdUI;->addButtons(Landroid/widget/LinearLayout;IIII)V

    goto/16 :goto_1ba

    :cond_f0
    move-object v1, v15

    const/16 v15, 0xa

    const/16 v3, 0x18

    .line 97
    invoke-direct {v0, v3}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v3

    .line 98
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v15, 0x1

    .line 99
    invoke-virtual {v4, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 100
    invoke-virtual {v4, v15}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v15, 0x4

    .line 101
    invoke-direct {v0, v15}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v15

    add-int/2addr v15, v3

    invoke-direct {v0, v5}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v5

    invoke-virtual {v4, v3, v15, v3, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 102
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v14, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v4, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v1, 0xe

    if-eqz v2, :cond_143

    .line 106
    new-instance v3, Landroid/widget/ImageView;

    invoke-direct {v3, v6}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 107
    sget-object v5, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 108
    invoke-virtual {v3, v2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 109
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x38

    invoke-direct {v0, v5}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v15

    invoke-direct {v0, v5}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v5

    invoke-direct {v2, v15, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 110
    invoke-direct {v0, v1}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v5

    iput v5, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 111
    invoke-virtual {v4, v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 113
    :cond_143
    iget-object v2, v7, Lcom/rmtad/x/AdConfig;->title:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_179

    .line 114
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 115
    iget-object v3, v7, Lcom/rmtad/x/AdConfig;->title:Ljava/lang/String;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 116
    sget v3, Lcom/rmtad/x/AdUI;->C_TITLE:I

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v3, 0x41a00000  # 20.0f

    .line 117
    invoke-virtual {v2, v8, v3}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 118
    sget-object v3, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/16 v3, 0x11

    .line 119
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setGravity(I)V

    .line 120
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v14, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v15, 0xa

    .line 122
    invoke-direct {v0, v15}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v5

    iput v5, v3, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 123
    invoke-virtual {v4, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 125
    :cond_179
    iget-object v2, v7, Lcom/rmtad/x/AdConfig;->message:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_1af

    .line 126
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 127
    iget-object v3, v7, Lcom/rmtad/x/AdConfig;->message:Ljava/lang/String;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 128
    sget v3, Lcom/rmtad/x/AdUI;->C_TEXT:I

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v3, 0x41700000  # 15.0f

    .line 129
    invoke-virtual {v2, v8, v3}, Landroid/widget/TextView;->setTextSize(IF)V

    const/4 v3, 0x0

    const/high16 v5, 0x3fa00000  # 1.25f

    .line 130
    invoke-virtual {v2, v3, v5}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/16 v3, 0x11

    .line 131
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setGravity(I)V

    .line 132
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v14, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v5, 0x6

    .line 134
    invoke-direct {v0, v5}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v5

    iput v5, v3, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 135
    invoke-virtual {v4, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 137
    :cond_1af
    invoke-direct {v0, v1}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v3

    move-object v1, v4

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v2, 0x0

    invoke-direct/range {v0 .. v5}, Lcom/rmtad/x/AdUI;->addButtons(Landroid/widget/LinearLayout;IIII)V

    :goto_1ba
    if-nez v11, :cond_21b

    .line 141
    iget-boolean v1, v7, Lcom/rmtad/x/AdConfig;->showClose:Z

    if-eqz v1, :cond_21b

    .line 142
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 143
    const-string v2, "✕"

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 144
    invoke-virtual {v1, v14}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v3, 0x41700000  # 15.0f

    .line 145
    invoke-virtual {v1, v8, v3}, Landroid/widget/TextView;->setTextSize(IF)V

    const/16 v3, 0x11

    .line 146
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setGravity(I)V

    .line 147
    const-string v2, "Close"

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 148
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v15, 0x1

    .line 149
    invoke-virtual {v2, v15}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 150
    sget v3, Lcom/rmtad/x/AdUI;->C_SCRIM:I

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 151
    invoke-static {v1, v2}, Lcom/rmtad/x/AdUI;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 152
    invoke-virtual {v1, v15}, Landroid/widget/TextView;->setClickable(Z)V

    .line 153
    new-instance v2, Lcom/rmtad/x/AdUI$1;

    invoke-direct {v2, v0}, Lcom/rmtad/x/AdUI$1;-><init>(Lcom/rmtad/x/AdUI;)V

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 159
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v3, 0x24

    invoke-direct {v0, v3}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v4

    invoke-direct {v0, v3}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v3

    const v5, 0x800035

    invoke-direct {v2, v4, v3, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v15, 0xa

    .line 161
    invoke-direct {v0, v15}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v3

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 162
    invoke-direct {v0, v15}, Lcom/rmtad/x/AdUI;->dp(I)I

    move-result v3

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 163
    invoke-virtual {v13, v1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 166
    :cond_21b
    new-instance v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-direct {v1, v10, v9}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v13, v1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 168
    invoke-virtual {v12}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-eqz v1, :cond_243

    .line 170
    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v1, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 171
    invoke-virtual {v1, v10, v9}, Landroid/view/Window;->setLayout(II)V

    const/16 v3, 0x11

    .line 172
    invoke-virtual {v1, v3}, Landroid/view/Window;->setGravity(I)V

    .line 173
    invoke-virtual {v1, v8}, Landroid/view/Window;->addFlags(I)V

    const v2, 0x3f3851ec  # 0.72f

    .line 174
    invoke-virtual {v1, v2}, Landroid/view/Window;->setDimAmount(F)V

    :cond_243
    xor-int/lit8 v1, v11, 0x1

    .line 178
    invoke-virtual {v12, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    xor-int/lit8 v1, v11, 0x1

    .line 179
    invoke-virtual {v12, v1}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    if-eqz v11, :cond_258

    .line 181
    new-instance v1, Lcom/rmtad/x/AdUI$2;

    invoke-direct {v1, v0}, Lcom/rmtad/x/AdUI$2;-><init>(Lcom/rmtad/x/AdUI;)V

    invoke-virtual {v12, v1}, Landroid/app/Dialog;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)V

    goto :goto_260

    .line 189
    :cond_258
    new-instance v1, Lcom/rmtad/x/AdUI$3;

    invoke-direct {v1, v0}, Lcom/rmtad/x/AdUI$3;-><init>(Lcom/rmtad/x/AdUI;)V

    invoke-virtual {v12, v1}, Landroid/app/Dialog;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V

    .line 197
    :goto_260
    iput-object v12, v0, Lcom/rmtad/x/AdUI;->dialog:Landroid/app/Dialog;

    .line 198
    invoke-virtual {v12}, Landroid/app/Dialog;->show()V

    const/16 v16, 0x1

    return v16
.end method
