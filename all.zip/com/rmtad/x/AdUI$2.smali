.class Lcom/rmtad/x/AdUI$2;
.super Ljava/lang/Object;
.source "AdUI.java"

# interfaces
.implements Landroid/content/DialogInterface$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/rmtad/x/AdUI;->show(Landroid/app/Activity;Lcom/rmtad/x/AdConfig;Landroid/graphics/Bitmap;Landroid/graphics/Bitmap;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/rmtad/x/AdUI;


# direct methods
.method constructor <init>(Lcom/rmtad/x/AdUI;)V
    .registers 2

    .line 181
    iput-object p1, p0, Lcom/rmtad/x/AdUI$2;->this$0:Lcom/rmtad/x/AdUI;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/content/DialogInterface;ILandroid/view/KeyEvent;)Z
    .registers 4

    const/4 p1, 0x4

    if-ne p2, p1, :cond_5

    const/4 p1, 0x1

    return p1

    :cond_5
    const/4 p1, 0x0

    return p1
.end method
