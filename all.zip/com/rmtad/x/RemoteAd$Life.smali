.class final Lcom/rmtad/x/RemoteAd$Life;
.super Ljava/lang/Object;
.source "RemoteAd.java"

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/rmtad/x/RemoteAd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Life"
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 377
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/rmtad/x/RemoteAd$1;)V
    .registers 2

    .line 377
    invoke-direct {p0}, Lcom/rmtad/x/RemoteAd$Life;-><init>()V

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .registers 3

    .line 412
    :try_start_0
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->access$1100()Landroid/app/Activity;

    move-result-object v0

    if-ne v0, p1, :cond_1d

    .line 413
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->access$1200()V

    .line 414
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->access$1300()Lcom/rmtad/x/AdUI;

    move-result-object p1

    const/4 v0, 0x0

    if-eqz p1, :cond_1a

    .line 415
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->access$1300()Lcom/rmtad/x/AdUI;

    move-result-object p1

    invoke-virtual {p1}, Lcom/rmtad/x/AdUI;->dismissSilently()V

    .line 416
    invoke-static {v0}, Lcom/rmtad/x/RemoteAd;->access$1302(Lcom/rmtad/x/AdUI;)Lcom/rmtad/x/AdUI;

    .line 418
    :cond_1a
    invoke-static {v0}, Lcom/rmtad/x/RemoteAd;->access$1002(Ljava/lang/ref/WeakReference;)Ljava/lang/ref/WeakReference;
    :try_end_1d
    .catchall {:try_start_0 .. :try_end_1d} :catchall_1d

    :catchall_1d
    :cond_1d
    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .registers 2

    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .registers 4

    .line 389
    :try_start_0
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->access$900()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_29

    invoke-static {}, Lcom/rmtad/x/RemoteAd;->access$900()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_29

    .line 390
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-static {v0}, Lcom/rmtad/x/RemoteAd;->access$1002(Ljava/lang/ref/WeakReference;)Ljava/lang/ref/WeakReference;

    .line 391
    invoke-static {}, Lcom/rmtad/x/RemoteAd;->access$100()Lcom/rmtad/x/AdConfig;

    move-result-object p1

    if-eqz p1, :cond_29

    invoke-static {}, Lcom/rmtad/x/RemoteAd;->access$500()V
    :try_end_29
    .catchall {:try_start_0 .. :try_end_29} :catchall_29

    :catchall_29
    :cond_29
    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .registers 2

    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .registers 2

    return-void
.end method
