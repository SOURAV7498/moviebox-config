.class Lcom/rmtad/x/RemoteAd$1;
.super Ljava/lang/Object;
.source "RemoteAd.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/rmtad/x/RemoteAd;->init(Landroid/app/Activity;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$activity:Landroid/app/Activity;

.field final synthetic val$configUrl:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/app/Activity;Ljava/lang/String;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 67
    iput-object p1, p0, Lcom/rmtad/x/RemoteAd$1;->val$activity:Landroid/app/Activity;

    iput-object p2, p0, Lcom/rmtad/x/RemoteAd$1;->val$configUrl:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 70
    iget-object v0, p0, Lcom/rmtad/x/RemoteAd$1;->val$activity:Landroid/app/Activity;

    iget-object v1, p0, Lcom/rmtad/x/RemoteAd$1;->val$configUrl:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/rmtad/x/RemoteAd;->init(Landroid/app/Activity;Ljava/lang/String;)V

    return-void
.end method
