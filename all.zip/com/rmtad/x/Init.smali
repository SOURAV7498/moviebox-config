.class public final Lcom/rmtad/x/Init;
.super Ljava/lang/Object;
.source "Init.java"


# static fields
.field private static final CONFIG_URL:Ljava/lang/String; = "https://pastebin.com/raw/xZurMEtY"


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static run(Landroid/app/Activity;)V
    .registers 2

    .line 24
    :try_start_0
    const-string v0, "https://pastebin.com/raw/xZurMEtY"

    invoke-static {p0, v0}, Lcom/rmtad/x/RemoteAd;->init(Landroid/app/Activity;Ljava/lang/String;)V
    :try_end_5
    .catchall {:try_start_0 .. :try_end_5} :catchall_5

    :catchall_5
    return-void
.end method
