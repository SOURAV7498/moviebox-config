.class Lcom/rmtad/x/RemoteAd$4;
.super Ljava/lang/Object;
.source "RemoteAd.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/rmtad/x/RemoteAd;->postShow(JI)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$attempt:I


# direct methods
.method constructor <init>(I)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 270
    iput p1, p0, Lcom/rmtad/x/RemoteAd$4;->val$attempt:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    const/4 v0, 0x0

    .line 273
    invoke-static {v0}, Lcom/rmtad/x/RemoteAd;->access$602(Ljava/lang/Runnable;)Ljava/lang/Runnable;

    .line 274
    iget v0, p0, Lcom/rmtad/x/RemoteAd$4;->val$attempt:I

    invoke-static {v0}, Lcom/rmtad/x/RemoteAd;->access$700(I)V

    return-void
.end method
