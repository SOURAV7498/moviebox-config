.class public Lcom/unknownmodz/update/UpdateDialog;
.super Landroid/app/Dialog;
.source "UpdateDialog.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/unknownmodz/update/UpdateDialog$100000000;,
        Lcom/unknownmodz/update/UpdateDialog$100000001;,
        Lcom/unknownmodz/update/UpdateDialog$100000002;
    }
.end annotation


# instance fields
.field private mContext:Landroid/content/Context;

.field private updateInfo:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;)V
    .registers 3

    invoke-direct {p0, p1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    iput-object p2, p0, Lcom/unknownmodz/update/UpdateDialog;->updateInfo:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    return-void
.end method

.method static synthetic access$L1000000(Lcom/unknownmodz/update/UpdateDialog;)Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;
    .registers 1

    iget-object p0, p0, Lcom/unknownmodz/update/UpdateDialog;->updateInfo:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    return-object p0
.end method

.method static synthetic access$L1000001(Lcom/unknownmodz/update/UpdateDialog;)Landroid/content/Context;
    .registers 1

    iget-object p0, p0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    return-object p0
.end method

.method static synthetic access$S1000000(Lcom/unknownmodz/update/UpdateDialog;Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;)V
    .registers 2

    iput-object p1, p0, Lcom/unknownmodz/update/UpdateDialog;->updateInfo:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    return-void
.end method

.method static synthetic access$S1000001(Lcom/unknownmodz/update/UpdateDialog;Landroid/content/Context;)V
    .registers 2

    iput-object p1, p0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    return-void
.end method

.method private appIcon()Landroid/graphics/drawable/Drawable;
    .registers 3

    :try_start_0
    iget-object v0, p0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_e} :catch_f

    return-object v0

    :catch_f
    move-exception v0

    const/4 v0, 0x0

    return-object v0
.end method

.method private btn()Landroid/widget/Button;
    .registers 6

    new-instance v0, Landroid/widget/Button;

    iget-object v1, p0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v1, "UPDATE NOW \ud83d\ude0a"

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTextColor(I)V

    const/high16 v1, 0x41900000  # 18.0f

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTextSize(F)V

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;I)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setAllCaps(Z)V

    const-string v1, "#2F6BFF"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    const/16 v2, 0x1c

    invoke-direct {p0, v2}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v2

    int-to-float v2, v2

    invoke-direct {p0, v1, v2}, Lcom/unknownmodz/update/UpdateDialog;->roundRect(IF)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1, v1, v1, v1}, Landroid/widget/Button;->setPadding(IIII)V

    const/16 v1, 0x38

    invoke-direct {p0, v1}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v1

    const/4 v2, -0x1

    const/16 v3, 0x16

    invoke-direct {p0, v2, v1, v3}, Lcom/unknownmodz/update/UpdateDialog;->lpm(III)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private dp(I)I
    .registers 3

    invoke-virtual {p0}, Lcom/unknownmodz/update/UpdateDialog;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    int-to-float p1, p1

    mul-float p1, p1, v0

    float-to-int p1, p1

    return p1
.end method

.method private label(Ljava/lang/CharSequence;FIZ)Landroid/widget/TextView;
    .registers 7

    new-instance v0, Landroid/widget/TextView;

    iget-object v1, p0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v0, p3}, Landroid/widget/TextView;->setTextColor(I)V

    if-eqz p4, :cond_17

    const/4 v1, 0x0

    const/4 p2, 0x1

    invoke-virtual {v0, v1, p2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_17
    return-object v0
.end method

.method private loadFromAssets(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 3

    :try_start_0
    iget-object v0, p0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p1

    invoke-static {p1}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v0

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_11} :catch_12

    return-object v0

    :catch_12
    move-exception p1

    const/4 p1, 0x0

    move-object v0, p1

    check-cast v0, Landroid/graphics/Bitmap;

    return-object p1
.end method

.method private lpm(III)Landroid/widget/LinearLayout$LayoutParams;
    .registers 6

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, p1, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-direct {p0, p3}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v1

    iput v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    return-object v0
.end method

.method private roundRect(IF)Landroid/graphics/drawable/GradientDrawable;
    .registers 5

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {v0, p2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method private roundRectStroke(IFII)Landroid/graphics/drawable/GradientDrawable;
    .registers 5

    invoke-direct {p0, p1, p2}, Lcom/unknownmodz/update/UpdateDialog;->roundRect(IF)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {p1, p4, p3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    return-object p1
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .registers 18
    .annotation runtime Ljava/lang/Override;
    .end annotation

    move-object/from16 v0, p0

    invoke-super/range {p0 .. p1}, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/unknownmodz/update/UpdateDialog;->requestWindowFeature(I)Z

    invoke-virtual {v0}, Lcom/unknownmodz/update/UpdateDialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    const/4 v4, 0x0

    invoke-direct {v3, v4}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v2, v3}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object v2, v0, Lcom/unknownmodz/update/UpdateDialog;->updateInfo:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    iget-boolean v2, v2, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->force:Z

    xor-int/2addr v2, v1

    invoke-virtual {v0, v2}, Lcom/unknownmodz/update/UpdateDialog;->setCancelable(Z)V

    invoke-virtual {v0, v2}, Lcom/unknownmodz/update/UpdateDialog;->setCanceledOnTouchOutside(Z)V

    invoke-virtual {v0}, Lcom/unknownmodz/update/UpdateDialog;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v14, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v15, v2, Landroid/util/DisplayMetrics;->heightPixels:I

    new-instance v2, Landroid/widget/ScrollView;

    iget-object v3, v0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-direct {v2, v3}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/ScrollView;->setVerticalScrollBarEnabled(Z)V

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v5, -0x2

    invoke-direct {v3, v4, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v3}, Landroid/widget/ScrollView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout;

    iget-object v4, v0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v4, 0x16

    invoke-direct {v0, v4}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v4

    invoke-virtual {v3, v4, v4, v4, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const-string v4, "#FAFBFF"

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const/16 v5, 0x1c

    invoke-direct {v0, v5}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v5

    int-to-float v5, v5

    invoke-direct {v0, v4, v5}, Lcom/unknownmodz/update/UpdateDialog;->roundRect(IF)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, -0x1

    const/4 v6, -0x2

    invoke-direct {v4, v5, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/LinearLayout;

    iget-object v5, v0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-direct {v4, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v5, 0x10

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v5, -0x1

    const/4 v6, -0x2

    const/4 v7, 0x0

    invoke-direct {v0, v5, v6, v7}, Lcom/unknownmodz/update/UpdateDialog;->lpm(III)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-direct {v0}, Lcom/unknownmodz/update/UpdateDialog;->appIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v5

    if-eqz v5, :cond_a7

    new-instance v6, Landroid/widget/ImageView;

    iget-object v7, v0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-direct {v6, v7}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6, v5}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    sget-object v5, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v6, v5}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    goto :goto_f2

    :cond_a7
    const-string v5, "logo.png"

    invoke-direct {v0, v5}, Lcom/unknownmodz/update/UpdateDialog;->loadFromAssets(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v5

    if-nez v5, :cond_b5

    const-string v5, "logo.jpg"

    invoke-direct {v0, v5}, Lcom/unknownmodz/update/UpdateDialog;->loadFromAssets(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v5

    :cond_b5
    if-nez v5, :cond_bd

    const-string v5, "logo.webp"

    invoke-direct {v0, v5}, Lcom/unknownmodz/update/UpdateDialog;->loadFromAssets(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v5

    :cond_bd
    if-eqz v5, :cond_cf

    new-instance v6, Landroid/widget/ImageView;

    iget-object v7, v0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-direct {v6, v7}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6, v5}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    sget-object v5, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v6, v5}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    goto :goto_f2

    :cond_cf
    const-string v5, "\ud83d\ude80"

    const/high16 v6, 0x41e00000  # 28.0f

    const/4 v7, -0x1

    const/4 v8, 0x0

    invoke-direct {v0, v5, v6, v7, v8}, Lcom/unknownmodz/update/UpdateDialog;->label(Ljava/lang/CharSequence;FIZ)Landroid/widget/TextView;

    move-result-object v6

    const/16 v5, 0x11

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setGravity(I)V

    const-string v5, "#E6EEFF"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    const/16 v7, 0x12

    invoke-direct {v0, v7}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v7

    int-to-float v7, v7

    invoke-direct {v0, v5, v7}, Lcom/unknownmodz/update/UpdateDialog;->roundRect(IF)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :goto_f2
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v7, 0x40

    invoke-direct {v0, v7}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v7

    invoke-direct {v5, v7, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v7, 0x10

    invoke-direct {v0, v7}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v7

    iput v7, v5, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    invoke-virtual {v6, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/LinearLayout;

    iget-object v6, v0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-direct {v5, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, 0x0

    const/4 v8, -0x2

    const/high16 v9, 0x3f800000  # 1.0f

    invoke-direct {v6, v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v6, v0, Lcom/unknownmodz/update/UpdateDialog;->updateInfo:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    iget-object v6, v6, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->title:Ljava/lang/String;

    const/high16 v7, 0x41b00000  # 22.0f

    const-string v8, "#111111"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/4 v9, 0x1

    invoke-direct {v0, v6, v7, v8, v9}, Lcom/unknownmodz/update/UpdateDialog;->label(Ljava/lang/CharSequence;FIZ)Landroid/widget/TextView;

    move-result-object v6

    const/4 v7, 0x2

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setMaxLines(I)V

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Latest: v"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, v0, Lcom/unknownmodz/update/UpdateDialog;->updateInfo:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    iget-object v7, v7, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->versionName:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " - Update"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/high16 v7, 0x41700000  # 15.0f

    const-string v8, "#22D36B"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/4 v9, 0x0

    invoke-direct {v0, v6, v7, v8, v9}, Lcom/unknownmodz/update/UpdateDialog;->label(Ljava/lang/CharSequence;FIZ)Landroid/widget/TextView;

    move-result-object v6

    const/4 v7, -0x2

    const/4 v8, 0x4

    invoke-direct {v0, v7, v7, v8}, Lcom/unknownmodz/update/UpdateDialog;->lpm(III)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    iget-object v4, v0, Lcom/unknownmodz/update/UpdateDialog;->updateInfo:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    iget-object v4, v4, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->message:Ljava/lang/String;

    if-eqz v4, :cond_19c

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    if-eqz v5, :cond_19c

    const/high16 v5, 0x41600000  # 14.0f

    const-string v6, "#6B7280"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    const/4 v7, 0x0

    invoke-direct {v0, v4, v5, v6, v7}, Lcom/unknownmodz/update/UpdateDialog;->label(Ljava/lang/CharSequence;FIZ)Landroid/widget/TextView;

    move-result-object v4

    const/4 v5, -0x1

    const/4 v6, -0x2

    const/16 v7, 0x12

    invoke-direct {v0, v5, v6, v7}, Lcom/unknownmodz/update/UpdateDialog;->lpm(III)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_19c
    new-instance v4, Landroid/widget/LinearLayout;

    iget-object v5, v0, Lcom/unknownmodz/update/UpdateDialog;->mContext:Landroid/content/Context;

    invoke-direct {v4, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v4, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v5, 0x14

    invoke-direct {v0, v5}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v5

    invoke-virtual {v4, v5, v5, v5, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const-string v5, "#EEF2FC"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    const/16 v6, 0x14

    invoke-direct {v0, v6}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v6

    int-to-float v6, v6

    invoke-direct {v0, v5, v6}, Lcom/unknownmodz/update/UpdateDialog;->roundRect(IF)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v5, -0x1

    const/4 v6, -0x2

    const/16 v7, 0x14

    invoke-direct {v0, v5, v6, v7}, Lcom/unknownmodz/update/UpdateDialog;->lpm(III)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x0

    iget-object v5, v0, Lcom/unknownmodz/update/UpdateDialog;->updateInfo:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    iget-object v5, v5, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->changelog:Ljava/util/List;

    if-eqz v5, :cond_21c

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v6

    const/4 v7, 0x0

    :goto_1da
    if-ge v7, v6, :cond_21c

    invoke-interface {v5, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    add-int/lit8 v10, v7, 0x1

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, ". "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/high16 v9, 0x41800000  # 16.0f

    const-string v10, "#4B5563"

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    const/4 v11, 0x0

    invoke-direct {v0, v8, v9, v10, v11}, Lcom/unknownmodz/update/UpdateDialog;->label(Ljava/lang/CharSequence;FIZ)Landroid/widget/TextView;

    move-result-object v8

    const/4 v9, 0x0

    if-eqz v7, :cond_20d

    const/16 v9, 0xe

    :cond_20d
    const/4 v10, -0x1

    const/4 v11, -0x2

    invoke-direct {v0, v10, v11, v9}, Lcom/unknownmodz/update/UpdateDialog;->lpm(III)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v4, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v7, v7, 0x1

    goto :goto_1da

    :cond_21c
    if-lez v6, :cond_221

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_221
    iget-object v4, v0, Lcom/unknownmodz/update/UpdateDialog;->updateInfo:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    iget-boolean v4, v4, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->force:Z

    if-eqz v4, :cond_237

    invoke-direct {v0}, Lcom/unknownmodz/update/UpdateDialog;->btn()Landroid/widget/Button;

    move-result-object v4

    new-instance v5, Lcom/unknownmodz/update/UpdateDialog$100000000;

    invoke-direct {v5, v0}, Lcom/unknownmodz/update/UpdateDialog$100000000;-><init>(Lcom/unknownmodz/update/UpdateDialog;)V

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_279

    :cond_237
    invoke-direct {v0}, Lcom/unknownmodz/update/UpdateDialog;->btn()Landroid/widget/Button;

    move-result-object v4

    new-instance v5, Lcom/unknownmodz/update/UpdateDialog$100000002;

    invoke-direct {v5, v0}, Lcom/unknownmodz/update/UpdateDialog$100000002;-><init>(Lcom/unknownmodz/update/UpdateDialog;)V

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v4, "Later"

    const/high16 v5, 0x41700000  # 15.0f

    const-string v6, "#9CA3AF"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    const/4 v7, 0x0

    invoke-direct {v0, v4, v5, v6, v7}, Lcom/unknownmodz/update/UpdateDialog;->label(Ljava/lang/CharSequence;FIZ)Landroid/widget/TextView;

    move-result-object v4

    const/16 v5, 0x11

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v5, 0xc

    invoke-direct {v0, v5}, Lcom/unknownmodz/update/UpdateDialog;->dp(I)I

    move-result v5

    const/4 v6, 0x0

    invoke-virtual {v4, v6, v5, v6, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    const/4 v5, -0x1

    const/4 v6, -0x2

    const/4 v7, 0x6

    invoke-direct {v0, v5, v6, v7}, Lcom/unknownmodz/update/UpdateDialog;->lpm(III)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v5, Lcom/unknownmodz/update/UpdateDialog$100000001;

    invoke-direct {v5, v0}, Lcom/unknownmodz/update/UpdateDialog$100000001;-><init>(Lcom/unknownmodz/update/UpdateDialog;)V

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :goto_279
    invoke-virtual {v2, v3}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v2}, Lcom/unknownmodz/update/UpdateDialog;->setContentView(Landroid/view/View;)V

    invoke-virtual {v0}, Lcom/unknownmodz/update/UpdateDialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v2

    invoke-static {v14, v15}, Ljava/lang/Math;->min(II)I

    move-result v3

    int-to-float v3, v3

    const v4, 0x3f666666  # 0.9f

    mul-float/2addr v3, v4

    float-to-int v3, v3

    iput v3, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v3, -0x2

    iput v3, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {v1, v2}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    return-void
.end method
