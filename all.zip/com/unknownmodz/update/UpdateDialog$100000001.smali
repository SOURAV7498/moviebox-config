.class Lcom/unknownmodz/update/UpdateDialog$100000001;
.super Ljava/lang/Object;
.source "UpdateDialog.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/unknownmodz/update/UpdateDialog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final this$0:Lcom/unknownmodz/update/UpdateDialog;


# direct methods
.method constructor <init>(Lcom/unknownmodz/update/UpdateDialog;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/unknownmodz/update/UpdateDialog$100000001;->this$0:Lcom/unknownmodz/update/UpdateDialog;

    return-void
.end method

.method static access$0(Lcom/unknownmodz/update/UpdateDialog$100000001;)Lcom/unknownmodz/update/UpdateDialog;
    .registers 1

    iget-object p0, p0, Lcom/unknownmodz/update/UpdateDialog$100000001;->this$0:Lcom/unknownmodz/update/UpdateDialog;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    iget-object p1, p0, Lcom/unknownmodz/update/UpdateDialog$100000001;->this$0:Lcom/unknownmodz/update/UpdateDialog;

    invoke-virtual {p1}, Lcom/unknownmodz/update/UpdateDialog;->dismiss()V

    return-void
.end method
