.class public Lcom/unknownmodz/update/Init;
.super Ljava/lang/Object;
.source "Init.java"


# direct methods
.method public static run(Landroid/app/Activity;)V
    .registers 1

    invoke-static {p0}, Lcom/Subscribe/DPMods/dialog/abror;->sD(Landroid/app/Activity;)V

    invoke-static {p0}, Lcom/unknownmodz/update/UpdateChecker;->Start(Landroid/content/Context;)V

    invoke-static {p0}, Lcom/rmtad/x/Init;->run(Landroid/app/Activity;)V

    return-void
.end method
