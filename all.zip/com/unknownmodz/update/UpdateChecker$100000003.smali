.class Lcom/unknownmodz/update/UpdateChecker$100000003;
.super Landroid/os/AsyncTask;
.source "UpdateChecker.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/unknownmodz/update/UpdateChecker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000003"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field private final synthetic val$callback:Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;

.field private final synthetic val$ctx:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;)V
    .registers 3

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    iput-object p1, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$ctx:Landroid/content/Context;

    iput-object p2, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$callback:Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;

    return-void
.end method


# virtual methods
.method protected bridge doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/unknownmodz/update/UpdateChecker$100000003;->doInBackground([Ljava/lang/Void;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/String;
    .registers 4
    .annotation runtime Ljava/lang/Override;
    .end annotation

    :try_start_0
    new-instance p1, Ljava/net/URL;

    const-string v0, "https://pastebin.com/raw/XXXXXX"

    invoke-direct {p1, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    check-cast p1, Ljava/net/HttpURLConnection;

    const-string v0, "GET"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/16 v0, 0x1388

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    new-instance v0, Ljava/io/BufferedReader;

    new-instance v1, Ljava/io/InputStreamReader;

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p1

    invoke-direct {v1, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    nop

    :goto_2e
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_3c

    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_3c
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_3f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_3f} :catch_40

    goto :goto_2e

    :catch_40
    move-exception p1

    const/4 p1, 0x0

    move-object v0, p1

    check-cast v0, Ljava/lang/String;

    return-object p1
.end method

.method protected bridge onPostExecute(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/unknownmodz/update/UpdateChecker$100000003;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    if-nez p1, :cond_2d

    iget-object p1, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$ctx:Landroid/content/Context;

    invoke-static {p1}, Lcom/unknownmodz/update/UpdateChecker;->access$1000014(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_25

    :try_start_a
    invoke-static {p1}, Lcom/unknownmodz/update/UpdateChecker;->access$1000015(Ljava/lang/String;)Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    move-result-object p1

    if-eqz p1, :cond_16

    iget-object v0, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$callback:Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;

    invoke-interface {v0, p1}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onUpdateAvailable(Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;)V

    goto :goto_1b

    :cond_16
    iget-object p1, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$callback:Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;

    invoke-interface {p1}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onNoUpdate()V
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_1b} :catch_1c

    :goto_1b
    goto :goto_24

    :catch_1c
    move-exception p1

    iget-object p1, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$callback:Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;

    const-string v0, "Cache error"

    invoke-interface {p1, v0}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onError(Ljava/lang/String;)V

    :goto_24
    goto :goto_2c

    :cond_25
    iget-object p1, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$callback:Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;

    const-string v0, "No connection"

    invoke-interface {p1, v0}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onError(Ljava/lang/String;)V

    :goto_2c
    return-void

    :cond_2d
    iget-object v0, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$ctx:Landroid/content/Context;

    invoke-static {v0, p1}, Lcom/unknownmodz/update/UpdateChecker;->access$1000013(Landroid/content/Context;Ljava/lang/String;)V

    :try_start_32
    invoke-static {p1}, Lcom/unknownmodz/update/UpdateChecker;->access$1000015(Ljava/lang/String;)Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    move-result-object p1

    if-eqz p1, :cond_3e

    iget-object v0, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$callback:Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;

    invoke-interface {v0, p1}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onUpdateAvailable(Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;)V

    goto :goto_43

    :cond_3e
    iget-object p1, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$callback:Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;

    invoke-interface {p1}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onNoUpdate()V
    :try_end_43
    .catch Ljava/lang/Exception; {:try_start_32 .. :try_end_43} :catch_44

    :goto_43
    goto :goto_4c

    :catch_44
    move-exception p1

    iget-object p1, p0, Lcom/unknownmodz/update/UpdateChecker$100000003;->val$callback:Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;

    const-string v0, "Parse error"

    invoke-interface {p1, v0}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onError(Ljava/lang/String;)V

    :goto_4c
    return-void
.end method
