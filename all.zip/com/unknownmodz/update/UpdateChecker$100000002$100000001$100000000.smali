.class Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;
.super Ljava/lang/Object;
.source "UpdateChecker.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;

.field private final synthetic val$activity:Landroid/app/Activity;

.field private final synthetic val$info:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;


# direct methods
.method constructor <init>(Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;Landroid/app/Activity;Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;->this$0:Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;

    iput-object p2, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;->val$activity:Landroid/app/Activity;

    iput-object p3, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;->val$info:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    return-void
.end method

.method static access$0(Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;)Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;
    .registers 1

    iget-object p0, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;->this$0:Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;

    return-object p0
.end method


# virtual methods
.method public run()V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    :try_start_0
    iget-object v0, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;->val$activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_16

    new-instance v0, Lcom/unknownmodz/update/UpdateDialog;

    iget-object v1, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;->val$activity:Landroid/app/Activity;

    iget-object v2, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;->val$info:Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    invoke-direct {v0, v1, v2}, Lcom/unknownmodz/update/UpdateDialog;-><init>(Landroid/content/Context;Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;)V

    invoke-virtual {v0}, Lcom/unknownmodz/update/UpdateDialog;->show()V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_14} :catch_15

    goto :goto_16

    :catch_15
    move-exception v0

    :cond_16
    :goto_16
    return-void
.end method
