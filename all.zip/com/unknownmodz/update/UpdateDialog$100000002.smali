.class Lcom/unknownmodz/update/UpdateDialog$100000002;
.super Ljava/lang/Object;
.source "UpdateDialog.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/unknownmodz/update/UpdateDialog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final this$0:Lcom/unknownmodz/update/UpdateDialog;


# direct methods
.method constructor <init>(Lcom/unknownmodz/update/UpdateDialog;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/unknownmodz/update/UpdateDialog$100000002;->this$0:Lcom/unknownmodz/update/UpdateDialog;

    return-void
.end method

.method static access$0(Lcom/unknownmodz/update/UpdateDialog$100000002;)Lcom/unknownmodz/update/UpdateDialog;
    .registers 1

    iget-object p0, p0, Lcom/unknownmodz/update/UpdateDialog$100000002;->this$0:Lcom/unknownmodz/update/UpdateDialog;

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    :try_start_0
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.intent.action.VIEW"

    iget-object v1, p0, Lcom/unknownmodz/update/UpdateDialog$100000002;->this$0:Lcom/unknownmodz/update/UpdateDialog;

    invoke-static {v1}, Lcom/unknownmodz/update/UpdateDialog;->access$L1000000(Lcom/unknownmodz/update/UpdateDialog;)Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    move-result-object v1

    iget-object v1, v1, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->updateUrl:Ljava/lang/String;

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-direct {p1, v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    iget-object v0, p0, Lcom/unknownmodz/update/UpdateDialog$100000002;->this$0:Lcom/unknownmodz/update/UpdateDialog;

    invoke-static {v0}, Lcom/unknownmodz/update/UpdateDialog;->access$L1000001(Lcom/unknownmodz/update/UpdateDialog;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_1c} :catch_1d

    goto :goto_1e

    :catch_1d
    move-exception p1

    :goto_1e
    iget-object p1, p0, Lcom/unknownmodz/update/UpdateDialog$100000002;->this$0:Lcom/unknownmodz/update/UpdateDialog;

    invoke-virtual {p1}, Lcom/unknownmodz/update/UpdateDialog;->dismiss()V

    return-void
.end method
