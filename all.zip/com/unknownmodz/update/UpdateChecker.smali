.class public Lcom/unknownmodz/update/UpdateChecker;
.super Ljava/lang/Object;
.source "UpdateChecker.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/unknownmodz/update/UpdateChecker$100000002;,
        Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;,
        Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;,
        Lcom/unknownmodz/update/UpdateChecker$100000003;
    }
.end annotation


# static fields
.field private static final ENCRYPTED_CLASS:[B

.field private static final KEY_CACHED:Ljava/lang/String; = "cached_update_json"

.field private static final PASTEBIN_URL:Ljava/lang/String; = "https://pastebin.com/raw/XXXXXX"

.field private static final PREFS_NAME:Ljava/lang/String; = "update_prefs"

.field private static final XOR_KEY:I = 0xab


# direct methods
.method static final constructor <clinit>()V
    .registers 1

    const/16 v0, 0x24

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    sput-object v0, Lcom/unknownmodz/update/UpdateChecker;->ENCRYPTED_CLASS:[B

    return-void

    :array_a
    .array-data 1
        -0x38t
        -0x3ct
        -0x3at
        -0x7bt
        -0x22t
        -0x3bt
        -0x40t
        -0x3bt
        -0x3ct
        -0x24t
        -0x3bt
        -0x3at
        -0x3ct
        -0x31t
        -0x2ft
        -0x7bt
        -0x22t
        -0x25t
        -0x31t
        -0x36t
        -0x21t
        -0x32t
        -0x7bt
        -0x2t
        -0x25t
        -0x31t
        -0x36t
        -0x21t
        -0x32t
        -0x18t
        -0x3dt
        -0x32t
        -0x38t
        -0x40t
        -0x32t
        -0x27t
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static Start(Landroid/content/Context;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    invoke-static {}, Lcom/unknownmodz/update/UpdateChecker;->integrityCheck()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    :cond_7
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/unknownmodz/update/UpdateChecker$100000002;

    invoke-direct {v1, p0, v0}, Lcom/unknownmodz/update/UpdateChecker$100000002;-><init>(Landroid/content/Context;Landroid/os/Handler;)V

    const/16 p0, 0x1f4

    int-to-long v2, p0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method static synthetic access$1000006()Z
    .registers 1

    invoke-static {}, Lcom/unknownmodz/update/UpdateChecker;->integrityCheck()Z

    move-result v0

    return v0
.end method

.method static synthetic access$1000012(Landroid/content/Context;)Landroid/app/Activity;
    .registers 1

    invoke-static {p0}, Lcom/unknownmodz/update/UpdateChecker;->getActivity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1000013(Landroid/content/Context;Ljava/lang/String;)V
    .registers 2

    invoke-static {p0, p1}, Lcom/unknownmodz/update/UpdateChecker;->saveToCache(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1000014(Landroid/content/Context;)Ljava/lang/String;
    .registers 1

    invoke-static {p0}, Lcom/unknownmodz/update/UpdateChecker;->loadFromCache(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1000015(Ljava/lang/String;)Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;
    .registers 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    invoke-static {p0}, Lcom/unknownmodz/update/UpdateChecker;->parse(Ljava/lang/String;)Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$L1000000()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/unknownmodz/update/UpdateChecker;->PASTEBIN_URL:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$S1000000(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/unknownmodz/update/UpdateChecker;->PASTEBIN_URL:Ljava/lang/String;

    return-void
.end method

.method public static check(Landroid/content/Context;Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;",
            ")V"
        }
    .end annotation

    invoke-static {p0}, Lcom/unknownmodz/update/UpdateChecker;->isOnline(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_23

    invoke-static {p0}, Lcom/unknownmodz/update/UpdateChecker;->loadFromCache(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_1f

    :try_start_c
    invoke-static {p0}, Lcom/unknownmodz/update/UpdateChecker;->parse(Ljava/lang/String;)Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    move-result-object p0

    if-eqz p0, :cond_16

    invoke-interface {p1, p0}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onUpdateAvailable(Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;)V

    goto :goto_19

    :cond_16
    invoke-interface {p1}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onNoUpdate()V
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_19} :catch_1a

    :goto_19
    goto :goto_1e

    :catch_1a
    move-exception p0

    invoke-interface {p1}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onNoUpdate()V

    :goto_1e
    goto :goto_22

    :cond_1f
    invoke-interface {p1}, Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;->onNoUpdate()V

    :goto_22
    return-void

    :cond_23
    new-instance v0, Lcom/unknownmodz/update/UpdateChecker$100000003;

    invoke-direct {v0, p0, p1}, Lcom/unknownmodz/update/UpdateChecker$100000003;-><init>(Landroid/content/Context;Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;)V

    const/4 p0, 0x0

    new-array p0, p0, [Ljava/lang/Void;

    invoke-virtual {v0, p0}, Lcom/unknownmodz/update/UpdateChecker$100000003;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method

.method private static decrypt([B)Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x0

    :goto_6
    array-length v2, p0

    if-lt v1, v2, :cond_e

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_e
    aget-byte v2, p0, v1

    and-int/lit16 v2, v2, 0xff

    xor-int/lit16 v2, v2, 0xab

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x1

    goto :goto_6
.end method

.method private static getActivity(Landroid/content/Context;)Landroid/app/Activity;
    .registers 2

    :try_start_0
    instance-of v0, p0, Landroid/app/Activity;

    if-eqz v0, :cond_7

    check-cast p0, Landroid/app/Activity;

    return-object p0

    :cond_7
    instance-of v0, p0, Landroid/content/ContextWrapper;

    if-eqz v0, :cond_17

    check-cast p0, Landroid/content/ContextWrapper;

    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0}, Lcom/unknownmodz/update/UpdateChecker;->getActivity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object p0
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_15} :catch_16

    return-object p0

    :catch_16
    move-exception p0

    :cond_17
    nop

    const/4 p0, 0x0

    move-object v0, p0

    check-cast v0, Landroid/app/Activity;

    return-object p0
.end method

.method private static integrityCheck()Z
    .registers 2

    :try_start_0
    const-string v0, "com.unknownmodz.update.UpdateChecker"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0
    :try_end_6
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_6} :catch_17
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_6} :catch_15

    :try_start_6
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lcom/unknownmodz/update/UpdateChecker;->ENCRYPTED_CLASS:[B

    invoke-static {v1}, Lcom/unknownmodz/update/UpdateChecker;->decrypt([B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0

    :catch_15
    move-exception v0

    goto :goto_22

    :catch_17
    move-exception v0

    new-instance v1, Ljava/lang/NoClassDefFoundError;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/NoClassDefFoundError;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_22
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_22} :catch_15

    :goto_22
    const/4 v0, 0x0

    return v0
.end method

.method public static isOnline(Landroid/content/Context;)Z
    .registers 3

    const/4 v0, 0x0

    :try_start_1
    const-string v1, "connectivity"

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/net/ConnectivityManager;

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p0

    if-eqz p0, :cond_17

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->isConnectedOrConnecting()Z

    move-result p0
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_13} :catch_18

    if-nez p0, :cond_16

    goto :goto_17

    :cond_16
    const/4 v0, 0x1

    :cond_17
    :goto_17
    return v0

    :catch_18
    move-exception p0

    return v0
.end method

.method private static loadFromCache(Landroid/content/Context;)Ljava/lang/String;
    .registers 4

    const/4 v0, 0x0

    :try_start_1
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string v1, "update_prefs"

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v1, "cached_update_json"

    move-object v2, v0

    check-cast v2, Ljava/lang/String;

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_15} :catch_16

    return-object p0

    :catch_16
    move-exception p0

    move-object p0, v0

    check-cast p0, Ljava/lang/String;

    return-object v0
.end method

.method private static parse(Ljava/lang/String;)Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p0, "show"

    invoke-virtual {v0, p0}, Lorg/json/JSONObject;->getBoolean(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_12

    const/4 p0, 0x0

    move-object v0, p0

    check-cast v0, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    return-object p0

    :cond_12
    new-instance p0, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;

    invoke-direct {p0}, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;-><init>()V

    const-string v1, "version_name"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->versionName:Ljava/lang/String;

    const-string v1, "version_code"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->versionCode:I

    const-string v1, "title"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->title:Ljava/lang/String;

    const-string v1, "message"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->message:Ljava/lang/String;

    const-string v1, "update_url"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->updateUrl:Ljava/lang/String;

    const-string v1, "force"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v1

    iput-boolean v1, p0, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->force:Z

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->changelog:Ljava/util/List;

    const-string v1, "changelog"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    nop

    :goto_56
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-lt v2, v1, :cond_5d

    return-object p0

    :cond_5d
    iget-object v1, p0, Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;->changelog:Ljava/util/List;

    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_56
.end method

.method private static saveToCache(Landroid/content/Context;Ljava/lang/String;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string v0, "update_prefs"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "cached_update_json"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_18} :catch_19

    goto :goto_1a

    :catch_19
    move-exception p0

    :goto_1a
    return-void
.end method
