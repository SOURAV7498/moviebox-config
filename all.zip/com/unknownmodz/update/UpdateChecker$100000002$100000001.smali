.class Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;
.super Ljava/lang/Object;
.source "UpdateChecker.java"

# interfaces
.implements Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/unknownmodz/update/UpdateChecker$100000002;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;
    }
.end annotation


# instance fields
.field private final this$0:Lcom/unknownmodz/update/UpdateChecker$100000002;

.field private final synthetic val$activity:Landroid/app/Activity;

.field private final synthetic val$handler:Landroid/os/Handler;


# direct methods
.method constructor <init>(Lcom/unknownmodz/update/UpdateChecker$100000002;Landroid/os/Handler;Landroid/app/Activity;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;->this$0:Lcom/unknownmodz/update/UpdateChecker$100000002;

    iput-object p2, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;->val$handler:Landroid/os/Handler;

    iput-object p3, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;->val$activity:Landroid/app/Activity;

    return-void
.end method

.method static access$0(Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;)Lcom/unknownmodz/update/UpdateChecker$100000002;
    .registers 1

    iget-object p0, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;->this$0:Lcom/unknownmodz/update/UpdateChecker$100000002;

    return-object p0
.end method


# virtual methods
.method public onError(Ljava/lang/String;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method

.method public onNoUpdate()V
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method

.method public onUpdateAvailable(Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    iget-object v0, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;->val$handler:Landroid/os/Handler;

    new-instance v1, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;

    iget-object v2, p0, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;->val$activity:Landroid/app/Activity;

    invoke-direct {v1, p0, v2, p1}, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001$100000000;-><init>(Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;Landroid/app/Activity;Lcom/unknownmodz/update/UpdateChecker$UpdateInfo;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
