.class Lcom/unknownmodz/update/UpdateChecker$100000002;
.super Ljava/lang/Object;
.source "UpdateChecker.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/unknownmodz/update/UpdateChecker;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;
    }
.end annotation


# instance fields
.field private final synthetic val$ctx:Landroid/content/Context;

.field private final synthetic val$handler:Landroid/os/Handler;


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/os/Handler;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/unknownmodz/update/UpdateChecker$100000002;->val$ctx:Landroid/content/Context;

    iput-object p2, p0, Lcom/unknownmodz/update/UpdateChecker$100000002;->val$handler:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    :try_start_0
    invoke-static {}, Lcom/unknownmodz/update/UpdateChecker;->access$1000006()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    :cond_7
    iget-object v0, p0, Lcom/unknownmodz/update/UpdateChecker$100000002;->val$ctx:Landroid/content/Context;

    invoke-static {v0}, Lcom/unknownmodz/update/UpdateChecker;->access$1000012(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object v0

    if-eqz v0, :cond_23

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    if-eqz v1, :cond_16

    goto :goto_23

    :cond_16
    iget-object v1, p0, Lcom/unknownmodz/update/UpdateChecker$100000002;->val$ctx:Landroid/content/Context;

    new-instance v2, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;

    iget-object v3, p0, Lcom/unknownmodz/update/UpdateChecker$100000002;->val$handler:Landroid/os/Handler;

    invoke-direct {v2, p0, v3, v0}, Lcom/unknownmodz/update/UpdateChecker$100000002$100000001;-><init>(Lcom/unknownmodz/update/UpdateChecker$100000002;Landroid/os/Handler;Landroid/app/Activity;)V

    invoke-static {v1, v2}, Lcom/unknownmodz/update/UpdateChecker;->check(Landroid/content/Context;Lcom/unknownmodz/update/UpdateChecker$UpdateCallback;)V
    :try_end_22
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_22} :catch_24

    goto :goto_25

    :cond_23
    :goto_23
    return-void

    :catch_24
    move-exception v0

    :goto_25
    return-void
.end method
