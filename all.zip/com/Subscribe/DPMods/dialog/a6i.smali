.class Lcom/Subscribe/DPMods/dialog/a6i;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/Subscribe/DPMods/dialog/abror;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = null
.end annotation


# instance fields
.field private final a14:Lcom/Subscribe/DPMods/dialog/abror;


# direct methods
.method constructor <init>(Lcom/Subscribe/DPMods/dialog/abror;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/Subscribe/DPMods/dialog/a6i;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    return-void
.end method

.method static a15(Lcom/Subscribe/DPMods/dialog/a6i;)Lcom/Subscribe/DPMods/dialog/abror;
    .registers 2

    iget-object v0, p0, Lcom/Subscribe/DPMods/dialog/a6i;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    iget-object v0, p0, Lcom/Subscribe/DPMods/dialog/a6i;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    invoke-static {v0}, Lcom/Subscribe/DPMods/dialog/abror;->access$1000007(Lcom/Subscribe/DPMods/dialog/abror;)V

    iget-object v0, p0, Lcom/Subscribe/DPMods/dialog/a6i;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    invoke-virtual {v0}, Lcom/Subscribe/DPMods/dialog/abror;->dismiss()V

    return-void
.end method
