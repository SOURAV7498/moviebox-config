.class public Lcom/Subscribe/DPMods/dialog/a9z;
.super Landroid/graphics/drawable/Drawable;


# instance fields
.field private base:Landroid/graphics/drawable/Drawable;

.field private paint:Landroid/graphics/Paint;

.field private t0:J


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .registers 5

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    iput-object p1, p0, Lcom/Subscribe/DPMods/dialog/a9z;->base:Landroid/graphics/drawable/Drawable;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    iput-object v0, p0, Lcom/Subscribe/DPMods/dialog/a9z;->paint:Landroid/graphics/Paint;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/Subscribe/DPMods/dialog/a9z;->t0:J

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 16

    iget-object v0, p0, Lcom/Subscribe/DPMods/dialog/a9z;->base:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v7

    invoke-virtual {v0, v7}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {v7}, Landroid/graphics/Rect;->width()I

    move-result v1

    int-to-float v2, v1

    invoke-virtual {v7}, Landroid/graphics/Rect;->height()I

    move-result v1

    int-to-float v3, v1

    iget v1, v7, Landroid/graphics/Rect;->left:I

    int-to-float v4, v1

    iget v1, v7, Landroid/graphics/Rect;->top:I

    int-to-float v5, v1

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v7

    iget-wide v9, p0, Lcom/Subscribe/DPMods/dialog/a9z;->t0:J

    sub-long/2addr v7, v9

    long-to-float v6, v7

    const v7, 0x3a83126f  # 0.001f

    mul-float/2addr v6, v7

    iget-object v0, p0, Lcom/Subscribe/DPMods/dialog/a9z;->paint:Landroid/graphics/Paint;

    const/4 v1, 0x0

    :goto_2b
    const/16 v7, 0xe

    if-ge v1, v7, :cond_a1

    add-int/lit8 v7, v1, 0x1

    int-to-float v7, v7

    const v8, 0x3f413faa

    mul-float/2addr v8, v7

    const v9, 0x3f800000  # 1.0f

    rem-float/2addr v8, v9

    const v10, 0x42480000  # 50.0f

    mul-float/2addr v10, v8

    float-to-int v10, v10

    add-int/lit8 v10, v10, 0x1c

    invoke-virtual {v0, v10}, Landroid/graphics/Paint;->setAlpha(I)V

    const v10, 0x3ce56042  # 0.028f

    mul-float/2addr v8, v10

    const v10, 0x3c449ba6  # 0.012f

    add-float/2addr v8, v10

    mul-float/2addr v8, v2

    add-float v9, v8, v8

    add-float/2addr v9, v3

    const v10, 0x3f11e10e

    mul-float/2addr v10, v7

    const v11, 0x3f800000  # 1.0f

    rem-float/2addr v10, v11

    const v11, 0x3d4ccccd  # 0.05f

    mul-float/2addr v10, v11

    const v11, 0x3d0f5c29  # 0.035f

    add-float/2addr v10, v11

    mul-float/2addr v10, v3

    mul-float/2addr v10, v6

    const v11, 0x3f51b54a

    mul-float/2addr v11, v7

    const v12, 0x3f800000  # 1.0f

    rem-float/2addr v11, v12

    mul-float v12, v11, v9

    add-float/2addr v10, v12

    rem-float/2addr v10, v9

    add-float v12, v5, v3

    add-float/2addr v12, v8

    sub-float/2addr v12, v10

    const v10, 0x3f19999a  # 0.6f

    mul-float/2addr v10, v11

    const v11, 0x3f000000  # 0.5f

    add-float/2addr v10, v11

    mul-float/2addr v10, v6

    add-float/2addr v10, v7

    float-to-double v10, v10

    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    double-to-float v10, v10

    const v11, 0x3cf5c28f  # 0.03f

    mul-float/2addr v10, v11

    mul-float/2addr v10, v2

    const v11, 0x3f1e3778

    mul-float/2addr v11, v7

    const v13, 0x3f800000  # 1.0f

    rem-float/2addr v11, v13

    const v13, 0x3f4ccccd  # 0.8f

    mul-float/2addr v11, v13

    const v13, 0x3dcccccd  # 0.1f

    add-float/2addr v11, v13

    mul-float/2addr v11, v2

    add-float/2addr v11, v4

    add-float/2addr v11, v10

    invoke-virtual {p1, v11, v12, v8, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_2b

    :cond_a1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method

.method public getOpacity()I
    .registers 2

    const/4 v0, -0x3

    return v0
.end method

.method public setAlpha(I)V
    .registers 2

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 2

    return-void
.end method
