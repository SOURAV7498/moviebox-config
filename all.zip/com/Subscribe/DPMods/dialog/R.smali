.class public final Lcom/Subscribe/DPMods/dialog/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/Subscribe/DPMods/dialog/a1i;,
        Lcom/Subscribe/DPMods/dialog/a1n;,
        Lcom/Subscribe/DPMods/dialog/a28;,
        Lcom/Subscribe/DPMods/dialog/a3t;,
        Lcom/Subscribe/DPMods/dialog/a4w;,
        Lcom/Subscribe/DPMods/dialog/a6c;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
