.class Lcom/Subscribe/DPMods/dialog/a80;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/Subscribe/DPMods/dialog/abror;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = null
.end annotation


# instance fields
.field private final a14:Lcom/Subscribe/DPMods/dialog/abror;

.field private final a15:Landroid/app/AlertDialog;


# direct methods
.method constructor <init>(Lcom/Subscribe/DPMods/dialog/abror;Landroid/app/AlertDialog;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/Subscribe/DPMods/dialog/a80;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    iput-object p2, p0, Lcom/Subscribe/DPMods/dialog/a80;->a15:Landroid/app/AlertDialog;

    return-void
.end method

.method static a15(Lcom/Subscribe/DPMods/dialog/a80;)Lcom/Subscribe/DPMods/dialog/abror;
    .registers 2

    iget-object v0, p0, Lcom/Subscribe/DPMods/dialog/a80;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    return-object v0
.end method


# virtual methods
.method public onShow(Landroid/content/DialogInterface;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    iget-object v0, p0, Lcom/Subscribe/DPMods/dialog/a80;->a15:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_36

    new-instance v1, Landroid/view/WindowManager$LayoutParams;

    invoke-direct {v1}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/WindowManager$LayoutParams;->copyFrom(Landroid/view/WindowManager$LayoutParams;)I

    iget-object v2, p0, Lcom/Subscribe/DPMods/dialog/a80;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    invoke-virtual {v2}, Lcom/Subscribe/DPMods/dialog/abror;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-double v2, v2

    const-wide v4, 0x3fe999999999999aL  # 0.8

    mul-double/2addr v2, v4

    double-to-int v2, v2

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-virtual {v0, v1}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    iget-object v1, p0, Lcom/Subscribe/DPMods/dialog/a80;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    invoke-static {v1}, Lcom/Subscribe/DPMods/dialog/abror;->access$1000012(Lcom/Subscribe/DPMods/dialog/abror;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_36
    return-void
.end method
