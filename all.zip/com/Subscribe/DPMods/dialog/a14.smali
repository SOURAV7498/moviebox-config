.class public final Lcom/Subscribe/DPMods/dialog/a14;
.super Ljava/lang/Object;


# static fields
.field public static final a14:Ljava/lang/String; = "com.xtreme.modding.codes"

.field public static final a15:Ljava/lang/String; = "debug"

.field public static final a1i:Z = true

.field public static final a1n:J = 0x1L

.field public static final a28:Ljava/lang/String; = "1.0"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
