.class public Lcom/Subscribe/DPMods/dialog/customize/dimens;
.super Ljava/lang/Object;
.source "dimens.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getButtonCornerRadius()I
    .registers 1

    const/16 v0, 0x18

    return v0
.end method

.method public static getButtonMargin()I
    .registers 1

    const/16 v0, 0x8

    return v0
.end method

.method public static getButtonTextSize()I
    .registers 1

    const/16 v0, 0x10

    return v0
.end method

.method public static getCornerRadius()I
    .registers 1

    const/16 v0, 0x18

    return v0
.end method

.method public static getIconBorder()I
    .registers 1

    const/4 v0, 0x7

    return v0
.end method

.method public static getIconMargin()I
    .registers 1

    const/16 v0, 0x4

    return v0
.end method

.method public static getIconSize()I
    .registers 1

    const/16 v0, 0x58

    return v0
.end method

.method public static getMessagePadding()I
    .registers 1

    const/16 v0, 0xc

    return v0
.end method

.method public static getMessageTextSize()I
    .registers 1

    const/16 v0, 0xf

    return v0
.end method

.method public static getPadding()I
    .registers 1

    const/16 v0, 0x10

    return v0
.end method

.method public static getSeparatorSize()I
    .registers 1

    const/4 v0, 0x1

    return v0
.end method

.method public static getStrokeSize()I
    .registers 1

    const/4 v0, 0x2

    return v0
.end method

.method public static getSubtitleTextSize()I
    .registers 1

    const/16 v0, 0xe

    return v0
.end method

.method public static getSwitchCornerRadius()I
    .registers 1

    const/4 v0, 0x0

    return v0
.end method

.method public static getSwitchPadding()I
    .registers 1

    const/4 v0, 0x0

    return v0
.end method

.method public static getSwitchTextSize()I
    .registers 1

    const/4 v0, 0x0

    return v0
.end method

.method public static getTitlePadding()I
    .registers 1

    const/16 v0, 0x8

    return v0
.end method

.method public static getTitleTextSize()I
    .registers 1

    const/16 v0, 0x10

    return v0
.end method
