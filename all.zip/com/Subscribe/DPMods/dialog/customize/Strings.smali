.class public Lcom/Subscribe/DPMods/dialog/customize/Strings;
.super Ljava/lang/Object;
.source "Strings.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getIconName()Ljava/lang/String;
    .registers 1

    const-string v0, "avatar.png"

    return-object v0
.end method

.method public static getMessage()Ljava/lang/String;
    .registers 1

    const-string v0, "✦ Join our RooMODS Telegram channel to get the latest MOD APKs, premium features & updates first! \ud83d\udd25"

    return-object v0
.end method

.method public static getNegativeButton()Ljava/lang/String;
    .registers 1

    const-string v0, "Cancel"

    return-object v0
.end method

.method public static getPositiveButton()Ljava/lang/String;
    .registers 1

    const-string v0, "JOIN NOW"

    return-object v0
.end method

.method public static getPositiveButtonLink()Ljava/lang/String;
    .registers 1

    const-string v0, "https://t.me/RooMODS"

    return-object v0
.end method

.method public static getSubtitle()Ljava/lang/String;
    .registers 1

    const-string v0, "• Primium Apk"

    return-object v0
.end method

.method public static getSwitch()Ljava/lang/String;
    .registers 1

    const-string v0, ""

    return-object v0
.end method

.method public static getTitle()Ljava/lang/String;
    .registers 1

    const-string v0, "RooMODS"

    return-object v0
.end method
