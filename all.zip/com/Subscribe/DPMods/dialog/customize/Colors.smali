.class public Lcom/Subscribe/DPMods/dialog/customize/Colors;
.super Ljava/lang/Object;
.source "Colors.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getButtonBgBottomColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#1D5FE0"

    return-object v0
.end method

.method public static getButtonBgTopColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#3FA2FF"

    return-object v0
.end method

.method public static getButtonTextColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#FFFFFF"

    return-object v0
.end method

.method public static getDialogBgBottomColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#071230"

    return-object v0
.end method

.method public static getDialogBgTopColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#12327A"

    return-object v0
.end method

.method public static getIconStrokeColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#FFFFFF"

    return-object v0
.end method

.method public static getMessageBgBottomColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#14FFFFFF"

    return-object v0
.end method

.method public static getMessageBgTopColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#26FFFFFF"

    return-object v0
.end method

.method public static getMessageTextColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#EAF2FF"

    return-object v0
.end method

.method public static getSeparatorColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#26FFFFFF"

    return-object v0
.end method

.method public static getStrokeColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#4D3FA2FF"

    return-object v0
.end method

.method public static getSubtitleTextColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#9DB6E0"

    return-object v0
.end method

.method public static getSwitchBgColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#00000000"

    return-object v0
.end method

.method public static getSwitchCheckedThumbColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#00000000"

    return-object v0
.end method

.method public static getSwitchCheckedTrackColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#00000000"

    return-object v0
.end method

.method public static getSwitchTextColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#00000000"

    return-object v0
.end method

.method public static getSwitchThumbColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#00000000"

    return-object v0
.end method

.method public static getSwitchTrackColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#00000000"

    return-object v0
.end method

.method public static getTitleBgLeftColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#2563EB"

    return-object v0
.end method

.method public static getTitleBgRightColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#0B2A75"

    return-object v0
.end method

.method public static getTitleBoxBgColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#00000000"

    return-object v0
.end method

.method public static getTitleTextColor()Ljava/lang/String;
    .registers 1

    const-string v0, "#FFFFFF"

    return-object v0
.end method
