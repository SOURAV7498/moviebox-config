.class Lcom/Subscribe/DPMods/dialog/a76;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/Subscribe/DPMods/dialog/abror;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = null
.end annotation


# instance fields
.field private final a14:Lcom/Subscribe/DPMods/dialog/abror;


# direct methods
.method constructor <init>(Lcom/Subscribe/DPMods/dialog/abror;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/Subscribe/DPMods/dialog/a76;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    return-void
.end method

.method static a15(Lcom/Subscribe/DPMods/dialog/a76;)Lcom/Subscribe/DPMods/dialog/abror;
    .registers 2

    iget-object v0, p0, Lcom/Subscribe/DPMods/dialog/a76;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    invoke-static {}, Lcom/Subscribe/DPMods/dialog/customize/Strings;->getPositiveButtonLink()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/Subscribe/DPMods/dialog/a76;->a14:Lcom/Subscribe/DPMods/dialog/abror;

    invoke-static {v1, v0}, Lcom/Subscribe/DPMods/dialog/abror;->access$1000006(Lcom/Subscribe/DPMods/dialog/abror;Ljava/lang/String;)V

    return-void
.end method
